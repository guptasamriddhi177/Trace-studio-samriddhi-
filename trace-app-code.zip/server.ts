import 'dotenv/config';
import fs from 'fs';
import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import JSZip from 'jszip';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import type {
  EvidenceItem,
  EvidenceStatus,
  GroundingLink,
  Investigation,
} from './src/types/trace';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in environment.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function isPrivateOrLoopbackHost(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (
    h === 'localhost' ||
    h === '127.0.0.1' ||
    h === '0.0.0.0' ||
    h === '::1' ||
    h.endsWith('.local') ||
    h.endsWith('.internal')
  ) {
    return true;
  }
  if (/^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h)) {
    return true;
  }
  if (/^169\.254\./.test(h)) {
    return true;
  }
  const match172 = h.match(/^172\.(\d+)\./);
  if (match172) {
    const second = Number(match172[1]);
    if (second >= 16 && second <= 31) return true;
  }
  if (h.startsWith('fc') || h.startsWith('fd') || h.startsWith('fe80:')) {
    return true;
  }
  return false;
}

function extractSafeUrls(text: string): string[] {
  const matches = text.match(/https?:\/\/[^\s<>"')]+/gi) || [];
  const safe: string[] = [];
  for (const raw of matches) {
    try {
      const parsed = new URL(raw);
      if (
        (parsed.protocol === 'http:' || parsed.protocol === 'https:') &&
        !isPrivateOrLoopbackHost(parsed.hostname)
      ) {
        safe.push(parsed.toString());
      }
    } catch {
      // Ignore malformed URLs
    }
  }
  return Array.from(new Set(safe)).slice(0, 5);
}

function sanitizeHttpUrl(url: string | undefined): string {
  if (!url || typeof url !== 'string') return '';
  try {
    const parsed = new URL(url.trim());
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.toString();
    }
  } catch {
    // ignore
  }
  return '';
}

function extractDomain(url: string, fallback = 'web-record'): string {
  try {
    const parsed = new URL(url);
    return parsed.hostname.replace(/^www\./, '');
  } catch {
    return fallback;
  }
}

function mapGeminiError(err: unknown): { status: number; message: string } {
  const msg = err instanceof Error ? err.message : String(err);
  if (msg.includes('GEMINI_API_KEY is not configured')) {
    return {
      status: 500,
      message:
        'Gemini API key is missing. Please verify GEMINI_API_KEY in the Settings > Secrets panel.',
    };
  }
  if (
    msg.includes('PERMISSION_DENIED') ||
    msg.includes('API_KEY_INVALID') ||
    msg.includes('403')
  ) {
    return {
      status: 403,
      message:
        'Gemini API authorization failed. Please verify your API key in Settings > Secrets.',
    };
  }
  if (msg.includes('RESOURCE_EXHAUSTED') || msg.includes('429')) {
    return {
      status: 429,
      message:
        'Gemini API rate limit or quota reached. Please wait a moment and try again.',
    };
  }
  return {
    status: 500,
    message: 'Investigation engine encountered an error while querying sources.',
  };
}

const VALID_STATUSES: EvidenceStatus[] = [
  'supported',
  'partially_supported',
  'contradicted',
  'unresolved',
  'outdated',
];

function normalizeStatus(status: string | undefined): EvidenceStatus {
  if (status && VALID_STATUSES.includes(status as EvidenceStatus)) {
    return status as EvidenceStatus;
  }
  return 'unresolved';
}

const investigationSchema = {
  type: Type.OBJECT,
  properties: {
    extractedClaim: {
      type: Type.STRING,
      description: 'Clean, neutral, testable formulation of the core claim.',
    },
    claimScope: {
      type: Type.STRING,
      description:
        'Who, what, where, and timeframe implied by the submitted claim.',
    },
    overallStatus: {
      type: Type.STRING,
      enum: [
        'supported',
        'partially_supported',
        'contradicted',
        'unresolved',
        'outdated',
      ],
    },
    conclusionHeadline: {
      type: Type.STRING,
      description:
        'Crisp one-sentence analytical headline summarizing what the evidence actually establishes (never use percentages or truth scores).',
    },
    conclusionDetail: {
      type: Type.STRING,
      description:
        'Transparent explanation linking conclusions directly to the discovered evidence, scope limitations, and contradictions.',
    },
    subQuestions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          question: { type: Type.STRING },
          findingSummary: { type: Type.STRING },
          status: {
            type: Type.STRING,
            enum: [
              'supported',
              'partially_supported',
              'contradicted',
              'unresolved',
              'outdated',
            ],
          },
          evidenceIds: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: ['id', 'question', 'findingSummary', 'status', 'evidenceIds'],
      },
    },
    evidence: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          title: { type: Type.STRING },
          url: { type: Type.STRING },
          domain: { type: Type.STRING },
          sourceType: {
            type: Type.STRING,
            enum: [
              'Official Statement',
              'Primary Record',
              'Wire Service',
              'Independent Reporting',
              'Derivative Repost',
              'Social Media Post',
              'Academic / Technical',
              'Archive / Earlier Context',
            ],
          },
          publicationDate: { type: Type.STRING },
          originStatus: {
            type: Type.STRING,
            enum: ['Original', 'Copied / Syndicated', 'Re-framed'],
          },
          evidenceBasis: {
            type: Type.STRING,
            enum: ['Direct Evidence', 'Inference'],
          },
          stance: {
            type: Type.STRING,
            enum: ['supporting', 'contradicting', 'context', 'origin'],
          },
          relevantQuestionId: { type: Type.STRING },
          summary: { type: Type.STRING },
          quoteOrExcerpt: { type: Type.STRING },
          limitations: { type: Type.STRING },
          parentEvidenceId: { type: Type.STRING },
          isIndependent: { type: Type.BOOLEAN },
        },
        required: [
          'id',
          'title',
          'url',
          'domain',
          'sourceType',
          'publicationDate',
          'originStatus',
          'evidenceBasis',
          'stance',
          'relevantQuestionId',
          'summary',
          'quoteOrExcerpt',
          'limitations',
          'isIndependent',
        ],
      },
    },
    sourceDna: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          label: { type: Type.STRING },
          domain: { type: Type.STRING },
          date: { type: Type.STRING },
          role: {
            type: Type.STRING,
            enum: [
              'Earliest Discoverable Origin',
              'Primary Official Source',
              'Independent Corroboration',
              'Amplifier / Repost',
              'Correction / Update',
            ],
          },
          dependsOnId: { type: Type.STRING },
          url: { type: Type.STRING },
          notes: { type: Type.STRING },
        },
        required: ['id', 'label', 'domain', 'date', 'role', 'notes'],
      },
    },
    contextShift: {
      type: Type.OBJECT,
      properties: {
        detected: { type: Type.BOOLEAN },
        severity: {
          type: Type.STRING,
          enum: ['None', 'Minor Reframing', 'Material Context Shift'],
        },
        summary: { type: Type.STRING },
        originalContext: { type: Type.STRING },
        currentFraming: { type: Type.STRING },
        temporalGap: { type: Type.STRING },
      },
      required: ['detected', 'severity', 'summary'],
    },
    unknowns: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          gap: { type: Type.STRING },
          whyItMatters: { type: Type.STRING },
          requiredToVerify: { type: Type.STRING },
        },
        required: ['id', 'gap', 'whyItMatters', 'requiredToVerify'],
      },
    },
  },
  required: [
    'extractedClaim',
    'claimScope',
    'overallStatus',
    'conclusionHeadline',
    'conclusionDetail',
    'subQuestions',
    'evidence',
    'sourceDna',
    'contextShift',
    'unknowns',
  ],
};

const app = express();
app.use(express.json({ limit: '1mb' }));

app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ ok: true });
});

app.post('/api/investigate', async (req: Request, res: Response) => {
  try {
    const rawInput = req.body?.input;
    if (typeof rawInput !== 'string' || rawInput.trim().length < 4) {
      res.status(400).json({
        error: 'Please enter a claim, headline, or public URL (at least 4 characters).',
      });
      return;
    }
    if (rawInput.length > 2000) {
      res.status(400).json({
        error: 'Submitted input exceeds the 2,000-character limit.',
      });
      return;
    }

    const input = rawInput.trim();
    const safeUrls = extractSafeUrls(input);
    const submittedType: 'claim' | 'url' =
      /^https?:\/\//i.test(input) && safeUrls.length > 0 ? 'url' : 'claim';

    const ai = getGeminiClient();
    const today = new Date().toISOString().split('T')[0];

    const researchTools: Array<Record<string, unknown>> = [{ googleSearch: {} }];
    if (safeUrls.length > 0) {
      researchTools.push({ urlContext: {} });
    }

    const researchPrompt = `Today's date is ${today}.
You are TRACE, an investigative evidence engine. Your job is NOT to write a generic fact-check verdict or assign truth percentages. Your job is to conduct a rigorous open-source investigation into the submission below and produce a detailed, source-grounded investigative memo.

SUBMISSION:
"""
${input}
"""

Conduct a thorough search across web sources and complete ALL six parts in your investigative memo:
1. CLAIM EXTRACTION & SCOPE: Extract the exact testable claim and define its scope (who, what, where, when, universal vs conditional).
2. SUB-QUESTIONS BREAKDOWN: Decompose the claim into 4 to 6 concrete investigative questions (e.g., Who originally made this claim? Is there an official announcement or primary record? Are reports independent or citing the same origin? Is the evidence recent? Does anything contradict or narrow it? What remains missing?).
3. SOURCE DNA (ORIGIN & DEPENDENCY): Trace the claim to its earliest discoverable appearance. Distinguish primary/official records and independent reporting from derivative reposts, wire syndication, or social media amplification citing the same origin.
4. CONTRADICTION ENGINE: Actively search for counter-evidence, official denials, narrower policy documents, corrections, or qualifiers that conflict with the viral framing.
5. CONTEXT SHIFT DETECTOR: Check whether an older photograph, video, quote, document, or past event is being recycled or reframed as current or broader than it originally was.
6. UNKNOWNS PANEL: Clearly document what cannot be established from public web records and what specific primary records would be required to resolve the remaining gaps.

For every source you cite, note its exact URL, publisher/domain, publication date (if discoverable), whether it is original vs copied/syndicated, whether it is direct evidence vs inference, and its limitations.`;

    const researchResponse = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: researchPrompt,
      config: {
        tools: researchTools,
        thinkingConfig: { thinkingLevel: ThinkingLevel.MEDIUM },
      },
    });

    const researchMemo = researchResponse.text ?? '';
    const chunks =
      researchResponse.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];

    const groundingUrls: GroundingLink[] = [];
    const seenUris = new Set<string>();
    for (const chunk of chunks) {
      const uri = sanitizeHttpUrl(chunk.web?.uri);
      const title = chunk.web?.title?.trim() || extractDomain(uri);
      if (uri && !seenUris.has(uri)) {
        seenUris.add(uri);
        groundingUrls.push({ title, uri });
      }
    }

    const structuringPrompt = `Today's retrieval date is ${today}.
Convert the grounded investigative memo below into a strict TRACE Investigation JSON structure following the TRACE Evidence Standard.

CRITICAL RULES:
- NEVER invent URLs. For the "url" field of evidence and sourceDna items, ONLY use verified URLs from the GROUNDED URLS list below (or from the user's submitted URL if valid). If a specific source has no verified URL in the list, use the closest matching verified URL from GROUNDED URLS or leave url as "".
- NEVER use truth percentage scores (e.g. "93% true"). Use the 5 TRACE Evidence Standard statuses strictly:
  - supported: Strong evidence directly supports the claim
  - partially_supported: Only some parts are supported (or claim is too broad / missing nuance)
  - contradicted: Credible evidence conflicts with the claim
  - unresolved: Available evidence is insufficient
  - outdated: The claim may once have been true but is no longer current
- Every evidence item MUST carry realistic limitations, publicationDate, originStatus ("Original", "Copied / Syndicated", or "Re-framed"), evidenceBasis ("Direct Evidence" or "Inference"), and parentEvidenceId if it relies on or republishes an earlier evidence item in the array.
- Ensure every subQuestion.evidenceIds references actual "id" values from the evidence array (e.g. "ev-1", "ev-2").
- Ensure sourceDna nodes trace the chronological lineage from earliest discoverable origin to downstream amplification/corrections, using dependsOnId to link child nodes to parent nodes.

SUBMISSION:
${input}

GROUNDED URLS DISCOVERED:
${groundingUrls.map((g, i) => `[${i + 1}] ${g.title} — ${g.uri}`).join('\n') || 'None returned directly in grounding chunks.'}

INVESTIGATIVE MEMO:
${researchMemo}`;

    const structuredResponse = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: structuringPrompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: investigationSchema,
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      },
    });

    const parsed = JSON.parse((structuredResponse.text ?? '{}').trim());

    const nowIso = new Date().toISOString();
    const evidenceList: EvidenceItem[] = Array.isArray(parsed.evidence)
      ? parsed.evidence.map((ev: Partial<EvidenceItem>, idx: number) => {
          const cleanUrl = sanitizeHttpUrl(ev.url);
          return {
            id: ev.id || `ev-${idx + 1}`,
            title: ev.title || 'Untitled Source',
            url: cleanUrl,
            domain: ev.domain || extractDomain(cleanUrl, 'public-record'),
            sourceType: ev.sourceType || 'Independent Reporting',
            publicationDate: ev.publicationDate || 'Date undisclosed',
            retrievalDate: today,
            originStatus: ev.originStatus || 'Original',
            evidenceBasis: ev.evidenceBasis || 'Direct Evidence',
            stance: ev.stance || 'context',
            relevantQuestionId: ev.relevantQuestionId || 'q-1',
            summary: ev.summary || '',
            quoteOrExcerpt: ev.quoteOrExcerpt || '',
            limitations: ev.limitations || 'Requires primary record verification.',
            parentEvidenceId: ev.parentEvidenceId || undefined,
            isIndependent: Boolean(ev.isIndependent),
          };
        })
      : [];

    const independentCount = evidenceList.filter((e) => e.isIndependent).length;

    const investigation: Investigation = {
      id: `inv-${Date.now()}`,
      submittedInput: input,
      submittedType,
      extractedClaim: parsed.extractedClaim || input,
      claimScope: parsed.claimScope || 'Scope under assessment',
      createdAt: nowIso,
      lastCheckedAt: nowIso,
      overallStatus: normalizeStatus(parsed.overallStatus),
      conclusionHeadline:
        parsed.conclusionHeadline ||
        'Investigation assembled from available public records.',
      conclusionDetail:
        parsed.conclusionDetail ||
        'Inspect individual sub-questions, source dependencies, and unknowns below.',
      independentSourceCount: independentCount,
      totalSourceCount: evidenceList.length,
      subQuestions: Array.isArray(parsed.subQuestions)
        ? parsed.subQuestions.map((q: Record<string, unknown>, idx: number) => ({
            id: String(q.id || `q-${idx + 1}`),
            question: String(q.question || ''),
            findingSummary: String(q.findingSummary || ''),
            status: normalizeStatus(q.status as string | undefined),
            evidenceIds: Array.isArray(q.evidenceIds)
              ? q.evidenceIds.map(String)
              : [],
          }))
        : [],
      evidence: evidenceList,
      sourceDna: Array.isArray(parsed.sourceDna)
        ? parsed.sourceDna.map((n: Record<string, unknown>, idx: number) => ({
            id: String(n.id || `dna-${idx + 1}`),
            label: String(n.label || 'Source Node'),
            domain: String(n.domain || ''),
            date: String(n.date || 'Unknown'),
            role: (n.role as Investigation['sourceDna'][number]['role']) || 'Independent Corroboration',
            dependsOnId: n.dependsOnId ? String(n.dependsOnId) : undefined,
            url: sanitizeHttpUrl(n.url as string | undefined) || undefined,
            notes: String(n.notes || ''),
          }))
        : [],
      contextShift: {
        detected: Boolean(parsed.contextShift?.detected),
        severity: parsed.contextShift?.severity || 'None',
        summary:
          parsed.contextShift?.summary ||
          'No material temporal or framing shift detected in discovered records.',
        originalContext: parsed.contextShift?.originalContext || undefined,
        currentFraming: parsed.contextShift?.currentFraming || undefined,
        temporalGap: parsed.contextShift?.temporalGap || undefined,
      },
      unknowns: Array.isArray(parsed.unknowns)
        ? parsed.unknowns.map((u: Record<string, unknown>, idx: number) => ({
            id: String(u.id || `unk-${idx + 1}`),
            gap: String(u.gap || ''),
            whyItMatters: String(u.whyItMatters || ''),
            requiredToVerify: String(u.requiredToVerify || ''),
          }))
        : [],
      timeline: [
        {
          id: `tl-${Date.now()}`,
          timestamp: nowIso,
          eventType: 'Initial Investigation',
          summary: `Decomposed claim into ${Array.isArray(parsed.subQuestions) ? parsed.subQuestions.length : 0} investigative questions across ${evidenceList.length} sources (${independentCount} independent).`,
          statusAfter: normalizeStatus(parsed.overallStatus),
        },
      ],
      challenges: [],
      groundingUrls,
    };

    res.json({ investigation });
  } catch (err) {
    console.error('Error in /api/investigate:', err);
    const mapped = mapGeminiError(err);
    res.status(mapped.status).json({ error: mapped.message });
  }
});

const liveUpdateSchema = {
  type: Type.OBJECT,
  properties: {
    hasNewUpdates: { type: Type.BOOLEAN },
    deltaHeadline: { type: Type.STRING },
    deltaDetails: { type: Type.STRING },
    recommendedStatus: {
      type: Type.STRING,
      enum: [
        'supported',
        'partially_supported',
        'contradicted',
        'unresolved',
        'outdated',
      ],
    },
    updatedConclusionDetail: { type: Type.STRING },
    newEvidence: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          url: { type: Type.STRING },
          domain: { type: Type.STRING },
          sourceType: {
            type: Type.STRING,
            enum: [
              'Official Statement',
              'Primary Record',
              'Wire Service',
              'Independent Reporting',
              'Derivative Repost',
              'Social Media Post',
              'Academic / Technical',
              'Archive / Earlier Context',
            ],
          },
          publicationDate: { type: Type.STRING },
          originStatus: {
            type: Type.STRING,
            enum: ['Original', 'Copied / Syndicated', 'Re-framed'],
          },
          evidenceBasis: {
            type: Type.STRING,
            enum: ['Direct Evidence', 'Inference'],
          },
          stance: {
            type: Type.STRING,
            enum: ['supporting', 'contradicting', 'context', 'origin'],
          },
          summary: { type: Type.STRING },
          quoteOrExcerpt: { type: Type.STRING },
          limitations: { type: Type.STRING },
          isIndependent: { type: Type.BOOLEAN },
        },
        required: [
          'title',
          'url',
          'domain',
          'sourceType',
          'publicationDate',
          'originStatus',
          'evidenceBasis',
          'stance',
          'summary',
          'quoteOrExcerpt',
          'limitations',
          'isIndependent',
        ],
      },
    },
  },
  required: [
    'hasNewUpdates',
    'deltaHeadline',
    'deltaDetails',
    'recommendedStatus',
    'updatedConclusionDetail',
    'newEvidence',
  ],
};

app.post('/api/investigate/refresh', async (req: Request, res: Response) => {
  try {
    const { extractedClaim, overallStatus, lastCheckedAt, existingSummary } =
      req.body ?? {};
    if (typeof extractedClaim !== 'string' || !extractedClaim.trim()) {
      res.status(400).json({ error: 'Missing extractedClaim for live check.' });
      return;
    }

    const ai = getGeminiClient();
    const today = new Date().toISOString().split('T')[0];

    const searchRes = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Today's date is ${today}.
Perform a TRACE LIVE re-check on this ongoing investigation:
Claim: "${extractedClaim.slice(0, 1000)}"
Previous status: ${String(overallStatus || 'unresolved')}
Previous summary: ${String(existingSummary || '').slice(0, 1000)}
Last checked: ${String(lastCheckedAt || 'earlier')}

Search the web specifically for:
- Official updates, press releases, or filings
- Corrections or retractions to earlier articles
- Newly published independent corroboration or contradictions
- Whether the claim's scope or currency has changed (e.g., now outdated or resolved).`,
      config: {
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      },
    });

    const chunks =
      searchRes.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
    const groundingUrls: GroundingLink[] = [];
    for (const c of chunks) {
      const uri = sanitizeHttpUrl(c.web?.uri);
      if (uri) {
        groundingUrls.push({
          title: c.web?.title?.trim() || extractDomain(uri),
          uri,
        });
      }
    }

    const structured = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Today's date is ${today}.
Compare the latest search findings against the previous investigation state and output a structured TRACE LIVE update delta.
Only include verified URLs from GROUNDED URLS below.

GROUNDED URLS:
${groundingUrls.map((g, i) => `[${i + 1}] ${g.title} — ${g.uri}`).join('\n') || 'None'}

LATEST FINDINGS:
${searchRes.text ?? ''}`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: liveUpdateSchema,
      },
    });

    const parsed = JSON.parse((structured.text ?? '{}').trim());
    const nowIso = new Date().toISOString();

    const newEvidence: EvidenceItem[] = Array.isArray(parsed.newEvidence)
      ? parsed.newEvidence.map((ev: Partial<EvidenceItem>, idx: number) => {
          const cleanUrl = sanitizeHttpUrl(ev.url);
          return {
            id: `ev-live-${Date.now()}-${idx + 1}`,
            title: ev.title || 'Live Update Record',
            url: cleanUrl,
            domain: ev.domain || extractDomain(cleanUrl, 'web-record'),
            sourceType: ev.sourceType || 'Independent Reporting',
            publicationDate: ev.publicationDate || today,
            retrievalDate: today,
            originStatus: ev.originStatus || 'Original',
            evidenceBasis: ev.evidenceBasis || 'Direct Evidence',
            stance: ev.stance || 'context',
            relevantQuestionId: 'q-1',
            summary: ev.summary || '',
            quoteOrExcerpt: ev.quoteOrExcerpt || '',
            limitations: ev.limitations || 'Retrieved during TRACE LIVE check.',
            isIndependent: Boolean(ev.isIndependent),
          };
        })
      : [];

    res.json({
      checkedAt: nowIso,
      hasNewUpdates: Boolean(parsed.hasNewUpdates),
      deltaHeadline: parsed.deltaHeadline || 'Live check completed.',
      deltaDetails: parsed.deltaDetails || '',
      recommendedStatus: normalizeStatus(parsed.recommendedStatus),
      updatedConclusionDetail: parsed.updatedConclusionDetail || '',
      newEvidence,
      groundingUrls,
    });
  } catch (err) {
    console.error('Error in /api/investigate/refresh:', err);
    const mapped = mapGeminiError(err);
    res.status(mapped.status).json({ error: mapped.message });
  }
});

const challengeSchema = {
  type: Type.OBJECT,
  properties: {
    assessment: { type: Type.STRING },
    impactOnStatus: { type: Type.STRING },
    suggestedStatus: {
      type: Type.STRING,
      enum: [
        'supported',
        'partially_supported',
        'contradicted',
        'unresolved',
        'outdated',
      ],
    },
    evidenceSummary: { type: Type.STRING },
    stance: {
      type: Type.STRING,
      enum: ['supporting', 'contradicting', 'context', 'origin'],
    },
    sourceType: {
      type: Type.STRING,
      enum: [
        'Official Statement',
        'Primary Record',
        'Wire Service',
        'Independent Reporting',
        'Derivative Repost',
        'Social Media Post',
        'Academic / Technical',
        'Archive / Earlier Context',
      ],
    },
    limitations: { type: Type.STRING },
  },
  required: [
    'assessment',
    'impactOnStatus',
    'suggestedStatus',
    'evidenceSummary',
    'stance',
    'sourceType',
    'limitations',
  ],
};

app.post('/api/investigate/challenge', async (req: Request, res: Response) => {
  try {
    const { extractedClaim, currentStatus, authorNote, referenceUrl } =
      req.body ?? {};
    if (typeof authorNote !== 'string' || authorNote.trim().length < 5) {
      res.status(400).json({
        error: 'Please provide an evidence note or challenge explanation (at least 5 characters).',
      });
      return;
    }

    const safeRefUrl = referenceUrl ? extractSafeUrls(String(referenceUrl))[0] : '';
    const tools: Array<Record<string, unknown>> = [{ googleSearch: {} }];
    if (safeRefUrl) {
      tools.push({ urlContext: {} });
    }

    const ai = getGeminiClient();
    const today = new Date().toISOString().split('T')[0];

    const evalRes = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `A user is contributing evidence or challenging a conclusion inside TRACE.
Claim under investigation: "${String(extractedClaim || '').slice(0, 1000)}"
Current status: ${String(currentStatus || 'unresolved')}
User note: "${authorNote.slice(0, 1000)}"
Reference URL: ${safeRefUrl || 'None provided'}

Evaluate this user-submitted evidence/challenge critically against open web records. Does it introduce a valid contradiction, primary source, or nuance, or does it remain unverified?`,
      config: {
        tools,
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      },
    });

    const structured = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `Format the assessment below into JSON.
Assessment memo:
${evalRes.text ?? ''}`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: challengeSchema,
      },
    });

    const parsed = JSON.parse((structured.text ?? '{}').trim());
    const nowIso = new Date().toISOString();

    const newEvidenceItem: EvidenceItem | null = safeRefUrl
      ? {
          id: `ev-user-${Date.now()}`,
          title: `Contributed Record (${extractDomain(safeRefUrl)})`,
          url: safeRefUrl,
          domain: extractDomain(safeRefUrl),
          sourceType: parsed.sourceType || 'Primary Record',
          publicationDate: today,
          retrievalDate: today,
          originStatus: 'Original',
          evidenceBasis: 'Direct Evidence',
          stance: parsed.stance || 'context',
          relevantQuestionId: 'q-1',
          summary: parsed.evidenceSummary || authorNote,
          quoteOrExcerpt: authorNote,
          limitations: parsed.limitations || 'Contributed by investigator; review primary source.',
          isIndependent: true,
        }
      : null;

    res.json({
      challenge: {
        id: `chg-${Date.now()}`,
        submittedAt: nowIso,
        authorNote: authorNote.trim(),
        referenceUrl: safeRefUrl || undefined,
        aiAssessment: parsed.assessment || '',
        impactOnStatus: parsed.impactOnStatus || '',
      },
      suggestedStatus: normalizeStatus(parsed.suggestedStatus),
      newEvidenceItem,
    });
  } catch (err) {
    console.error('Error in /api/investigate/challenge:', err);
    const mapped = mapGeminiError(err);
    res.status(mapped.status).json({ error: mapped.message });
  }
});

const EXPORT_ALLOWLIST_FILES = [
  '.env.example',
  '.gitignore',
  'bun.lock',
  'favicon.ico',
  'index.html',
  'metadata.json',
  'package.json',
  'server.ts',
  'tsconfig.json',
  'vite.config.ts',
];

const EXPORT_ALLOWLIST_DIRS = ['src', 'public'];

function appendDirToZip(zip: JSZip, dirAbs: string, rootAbs: string) {
  if (!fs.existsSync(dirAbs)) return;
  const entries = fs.readdirSync(dirAbs, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.isSymbolicLink()) continue;
    if (entry.name.startsWith('.env') && entry.name !== '.env.example') continue;
    if (entry.name.endsWith('.zip')) continue;

    const fullPath = path.resolve(dirAbs, entry.name);
    if (!fullPath.startsWith(rootAbs + path.sep)) continue;

    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === 'dist' || entry.name === '.git') {
        continue;
      }
      appendDirToZip(zip, fullPath, rootAbs);
    } else if (entry.isFile()) {
      const relPath = path.relative(rootAbs, fullPath).replace(/\\/g, '/');
      zip.file(relPath, fs.readFileSync(fullPath));
    }
  }
}

app.get('/api/export-code-zip', async (_req: Request, res: Response) => {
  try {
    const rootAbs = path.resolve(__dirname);
    const zip = new JSZip();

    for (const fileName of EXPORT_ALLOWLIST_FILES) {
      const fullPath = path.resolve(rootAbs, fileName);
      if (
        fullPath.startsWith(rootAbs + path.sep) &&
        fs.existsSync(fullPath) &&
        fs.statSync(fullPath).isFile()
      ) {
        zip.file(fileName, fs.readFileSync(fullPath));
      }
    }

    for (const dirName of EXPORT_ALLOWLIST_DIRS) {
      const dirAbs = path.resolve(rootAbs, dirName);
      if (dirAbs.startsWith(rootAbs + path.sep)) {
        appendDirToZip(zip, dirAbs, rootAbs);
      }
    }

    const buffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="trace-app-code.zip"'
    );
    res.setHeader('Cache-Control', 'no-store');
    res.send(buffer);
  } catch (err) {
    console.error('Error in /api/export-code-zip:', err);
    res.status(500).json({ error: 'Unable to package application source archive.' });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TRACE server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
