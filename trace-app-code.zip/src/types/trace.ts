export type EvidenceStatus =
  | 'supported'
  | 'partially_supported'
  | 'contradicted'
  | 'unresolved'
  | 'outdated';

export type EvidenceStance = 'supporting' | 'contradicting' | 'context' | 'origin';

export type SourceType =
  | 'Official Statement'
  | 'Primary Record'
  | 'Wire Service'
  | 'Independent Reporting'
  | 'Derivative Repost'
  | 'Social Media Post'
  | 'Academic / Technical'
  | 'Archive / Earlier Context';

export interface EvidenceItem {
  id: string;
  title: string;
  url: string;
  domain: string;
  sourceType: SourceType;
  publicationDate: string;
  retrievalDate: string;
  originStatus: 'Original' | 'Copied / Syndicated' | 'Re-framed';
  evidenceBasis: 'Direct Evidence' | 'Inference';
  stance: EvidenceStance;
  relevantQuestionId: string;
  summary: string;
  quoteOrExcerpt: string;
  limitations: string;
  parentEvidenceId?: string;
  isIndependent: boolean;
}

export interface SubQuestion {
  id: string;
  question: string;
  findingSummary: string;
  status: EvidenceStatus;
  evidenceIds: string[];
}

export interface SourceDnaNode {
  id: string;
  label: string;
  domain: string;
  date: string;
  role:
    | 'Earliest Discoverable Origin'
    | 'Primary Official Source'
    | 'Independent Corroboration'
    | 'Amplifier / Repost'
    | 'Correction / Update';
  dependsOnId?: string;
  url?: string;
  notes: string;
}

export interface ContextShiftFinding {
  detected: boolean;
  severity: 'None' | 'Minor Reframing' | 'Material Context Shift';
  summary: string;
  originalContext?: string;
  currentFraming?: string;
  temporalGap?: string;
}

export interface UnknownItem {
  id: string;
  gap: string;
  whyItMatters: string;
  requiredToVerify: string;
}

export interface TimelineEvent {
  id: string;
  timestamp: string;
  eventType:
    | 'Initial Investigation'
    | 'Live Update'
    | 'Correction Detected'
    | 'User Evidence Added';
  summary: string;
  statusAfter?: EvidenceStatus;
  deltaDetails?: string;
}

export interface UserChallenge {
  id: string;
  submittedAt: string;
  authorNote: string;
  referenceUrl?: string;
  aiAssessment?: string;
  impactOnStatus?: string;
}

export interface GroundingLink {
  title: string;
  uri: string;
}

export interface Investigation {
  id: string;
  submittedInput: string;
  submittedType: 'claim' | 'url';
  extractedClaim: string;
  claimScope: string;
  createdAt: string;
  lastCheckedAt: string;
  isReferenceCase?: boolean;
  overallStatus: EvidenceStatus;
  conclusionHeadline: string;
  conclusionDetail: string;
  independentSourceCount: number;
  totalSourceCount: number;
  subQuestions: SubQuestion[];
  evidence: EvidenceItem[];
  sourceDna: SourceDnaNode[];
  contextShift: ContextShiftFinding;
  unknowns: UnknownItem[];
  timeline: TimelineEvent[];
  challenges: UserChallenge[];
  groundingUrls: GroundingLink[];
}

export interface SourceNetworkProfile {
  domain: string;
  appearances: number;
  originCount: number;
  syndicatedCount: number;
  contradictionInvolvement: number;
  lastSeenAt: string;
  observedRoles: string[];
}
