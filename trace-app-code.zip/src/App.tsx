import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  Check,
  CheckCircle2,
  Download,
  ExternalLink,
  FileArchive,
  FolderOpen,
  Link2,
  Loader2,
  Menu,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import {
  REFERENCE_INVESTIGATIONS,
  STARTER_CLAIMS,
} from './data/referenceCases';
import type { EvidenceStatus, Investigation } from './types/trace';
import { StatusIndicator } from './components/StatusIndicator';
import { EvidenceGraph } from './components/EvidenceGraph';
import { SourceDnaPanel } from './components/SourceDnaPanel';
import { ContradictionAndContextPanel } from './components/ContradictionAndContextPanel';
import { UnknownsAndTimelinePanel } from './components/UnknownsAndTimelinePanel';
import { EvidenceLedger } from './components/EvidenceLedger';
import { SourceNetworkView } from './components/SourceNetworkView';
import { EvidenceStandardView } from './components/EvidenceStandardView';
import { exportInvestigationPdf } from './utils/exportInvestigationPdf';

type ActiveView = 'workspace' | 'graph' | 'network' | 'standard';

const STORAGE_KEY = 'trace_investigations_v1';

function loadInitialInvestigations(): Investigation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Investigation[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {
    // Fall back to reference dossiers
  }
  return REFERENCE_INVESTIGATIONS;
}

export default function App() {
  const [investigations, setInvestigations] = useState<Investigation[]>(
    loadInitialInvestigations
  );
  const [activeId, setActiveId] = useState<string>(
    () => loadInitialInvestigations()[0]?.id ?? REFERENCE_INVESTIGATIONS[0].id
  );
  const [activeView, setActiveView] = useState<ActiveView>('workspace');
  const [submissionInput, setSubmissionInput] = useState('');
  const [isInvestigating, setIsInvestigating] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSubmittingChallenge, setIsSubmittingChallenge] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedEvidenceId, setSelectedEvidenceId] = useState<string | null>(null);
  const [selectedQuestionId, setSelectedQuestionId] = useState<string | null>(null);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [pdfExported, setPdfExported] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(investigations));
    } catch {
      // Ignore storage quota errors
    }
  }, [investigations]);

  const activeInvestigation =
    investigations.find((inv) => inv.id === activeId) ?? investigations[0];

  const handleStartNewFocus = () => {
    setActiveView('workspace');
    setMobileSidebarOpen(false);
    setTimeout(() => {
      inputRef.current?.focus();
      inputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 50);
  };

  const handleExportPdf = () => {
    if (!activeInvestigation) return;
    try {
      exportInvestigationPdf(activeInvestigation);
      setPdfExported(true);
      window.setTimeout(() => setPdfExported(false), 2000);
    } catch {
      setErrorMessage('Unable to generate PDF dossier for this investigation.');
    }
  };

  const handleDownloadCodeZip = async () => {
    setErrorMessage(null);
    setIsDownloadingZip(true);
    try {
      const response = await fetch('/api/export-code-zip');
      if (!response.ok) {
        throw new Error('Failed to generate application ZIP archive.');
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'trace-app-code.zip';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Unable to download source archive.'
      );
    } finally {
      setIsDownloadingZip(false);
    }
  };

  const runInvestigation = async (queryText: string) => {
    const trimmed = queryText.trim();
    if (trimmed.length < 4) {
      setErrorMessage('Please enter a claim, headline, or public URL (at least 4 characters).');
      return;
    }

    setErrorMessage(null);
    setIsInvestigating(true);
    setSelectedEvidenceId(null);
    setSelectedQuestionId(null);
    setActiveView('workspace');

    try {
      const response = await fetch('/api/investigate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: trimmed }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to complete investigation.');
      }

      const created: Investigation = data.investigation;
      setInvestigations((prev) => [created, ...prev]);
      setActiveId(created.id);
      setSubmissionInput('');
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Unable to reach investigation engine.'
      );
    } finally {
      setIsInvestigating(false);
    }
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    runInvestigation(submissionInput);
  };

  const handleRunLiveCheck = async () => {
    if (!activeInvestigation) return;
    setErrorMessage(null);
    setIsRefreshing(true);

    try {
      const response = await fetch('/api/investigate/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          extractedClaim: activeInvestigation.extractedClaim,
          overallStatus: activeInvestigation.overallStatus,
          lastCheckedAt: activeInvestigation.lastCheckedAt,
          existingSummary: activeInvestigation.conclusionDetail,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to run TRACE LIVE update check.');
      }

      setInvestigations((prev) =>
        prev.map((inv) => {
          if (inv.id !== activeInvestigation.id) return inv;
          const mergedEvidence = [...inv.evidence, ...(data.newEvidence || [])];
          const newStatus: EvidenceStatus =
            data.recommendedStatus || inv.overallStatus;
          const timelineEntry = {
            id: `tl-${Date.now()}`,
            timestamp: data.checkedAt || new Date().toISOString(),
            eventType: data.hasNewUpdates
              ? ('Live Update' as const)
              : ('Live Update' as const),
            summary: data.deltaHeadline,
            deltaDetails: data.deltaDetails,
            statusAfter: newStatus,
          };

          const existingUris = new Set(inv.groundingUrls.map((g) => g.uri));
          const mergedGrounding = [
            ...inv.groundingUrls,
            ...(data.groundingUrls || []).filter(
              (g: { uri: string }) => !existingUris.has(g.uri)
            ),
          ];

          return {
            ...inv,
            lastCheckedAt: data.checkedAt || new Date().toISOString(),
            overallStatus: newStatus,
            conclusionDetail:
              data.hasNewUpdates && data.updatedConclusionDetail
                ? data.updatedConclusionDetail
                : inv.conclusionDetail,
            evidence: mergedEvidence,
            totalSourceCount: mergedEvidence.length,
            independentSourceCount: mergedEvidence.filter((e) => e.isIndependent)
              .length,
            timeline: [timelineEntry, ...inv.timeline],
            groundingUrls: mergedGrounding,
          };
        })
      );
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Unable to check for live updates.'
      );
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleSubmitChallenge = async (note: string, referenceUrl: string) => {
    if (!activeInvestigation) return;
    setErrorMessage(null);
    setIsSubmittingChallenge(true);

    try {
      const response = await fetch('/api/investigate/challenge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          extractedClaim: activeInvestigation.extractedClaim,
          currentStatus: activeInvestigation.overallStatus,
          authorNote: note,
          referenceUrl,
        }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to evaluate submitted evidence.');
      }

      setInvestigations((prev) =>
        prev.map((inv) => {
          if (inv.id !== activeInvestigation.id) return inv;
          const updatedEvidence = data.newEvidenceItem
            ? [...inv.evidence, data.newEvidenceItem]
            : inv.evidence;
          const newTimeline = [
            {
              id: `tl-${Date.now()}`,
              timestamp: new Date().toISOString(),
              eventType: 'User Evidence Added' as const,
              summary: `Investigator contributed note: "${note.slice(0, 90)}${note.length > 90 ? '…' : ''}"`,
              deltaDetails: data.challenge?.impactOnStatus,
              statusAfter: data.suggestedStatus || inv.overallStatus,
            },
            ...inv.timeline,
          ];

          return {
            ...inv,
            evidence: updatedEvidence,
            totalSourceCount: updatedEvidence.length,
            independentSourceCount: updatedEvidence.filter((e) => e.isIndependent)
              .length,
            challenges: [data.challenge, ...inv.challenges],
            timeline: newTimeline,
          };
        })
      );
    } catch (err) {
      setErrorMessage(
        err instanceof Error ? err.message : 'Unable to evaluate challenge.'
      );
    } finally {
      setIsSubmittingChallenge(false);
    }
  };

  const handleDeleteInvestigation = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setInvestigations((prev) => {
      const next = prev.filter((item) => item.id !== id);
      const fallback = next.length > 0 ? next : REFERENCE_INVESTIGATIONS;
      if (activeId === id) {
        setActiveId(fallback[0].id);
      }
      return fallback;
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single text element wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setMobileSidebarOpen((v) => !v)}
              aria-label="Toggle investigation archive"
              className="lg:hidden p-2 -ml-2 text-slate-700 hover:text-slate-900 cursor-pointer"
            >
              {mobileSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <button
              type="button"
              onClick={() => setActiveView('workspace')}
              className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer"
            >
              TRACE
            </button>
          </div>

          {/* Zone 2: 4 concise single-line navigation links */}
          <nav
            aria-label="Primary navigation"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600"
          >
            {(
              [
                ['workspace', 'Workspace'],
                ['graph', 'Evidence Graph'],
                ['network', 'Source Network'],
                ['standard', 'Evidence Standard'],
              ] as Array<[ActiveView, string]>
            ).map(([view, label]) => (
              <button
                key={view}
                type="button"
                onClick={() => setActiveView(view)}
                className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeView === view
                    ? 'text-slate-900 border-blue-700'
                    : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {label}
              </button>
            ))}
          </nav>

          {/* Zone 3: 1 primary action */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handleStartNewFocus}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" aria-hidden="true" />
              <span>New Investigation</span>
            </button>
          </div>
        </div>

        {/* Mobile view switch bar */}
        <div className="md:hidden border-t border-slate-100 px-4 py-2 flex items-center gap-4 overflow-x-auto text-xs font-medium">
          {(
            [
              ['workspace', 'Workspace'],
              ['graph', 'Evidence Graph'],
              ['network', 'Source Network'],
              ['standard', 'Evidence Standard'],
            ] as Array<[ActiveView, string]>
          ).map(([view, label]) => (
            <button
              key={view}
              type="button"
              onClick={() => setActiveView(view)}
              className={`whitespace-nowrap shrink-0 pb-1 border-b-2 cursor-pointer ${
                activeView === view
                  ? 'text-slate-900 border-blue-700'
                  : 'text-slate-600 border-transparent'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </header>

      {/* Main Workspace Frame */}
      <div className="flex-1 max-w-[1440px] w-full mx-auto flex relative">
        {/* Left Sidebar: Dossier Archive */}
        <aside
          className={`${
            mobileSidebarOpen
              ? 'fixed inset-y-16 left-0 z-20 flex shadow-lg'
              : 'hidden'
          } lg:static lg:flex flex-col justify-between w-72 shrink-0 bg-white border-r border-slate-200 p-4 overflow-y-auto`}
        >
          <div>
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
            <span className="text-xs font-mono font-semibold text-slate-500">
              INVESTIGATION DOSSIERS ({investigations.length})
            </span>
          </div>

          <div className="space-y-2">
            {investigations.map((inv) => {
              const isActive = inv.id === activeInvestigation?.id;
              return (
                <div
                  key={inv.id}
                  onClick={() => {
                    setActiveId(inv.id);
                    setSelectedEvidenceId(null);
                    setSelectedQuestionId(null);
                    setMobileSidebarOpen(false);
                    if (activeView === 'network' || activeView === 'standard') {
                      setActiveView('workspace');
                    }
                  }}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      setActiveId(inv.id);
                      setMobileSidebarOpen(false);
                    }
                  }}
                  className={`group p-3 rounded border transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-slate-50 border-slate-400'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <StatusIndicator status={inv.overallStatus} compact />
                    {!inv.isReferenceCase && (
                      <button
                        type="button"
                        onClick={(e) => handleDeleteInvestigation(inv.id, e)}
                        aria-label="Remove investigation"
                        className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-700 p-0.5 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <p className="text-xs font-semibold text-slate-900 line-clamp-2 leading-snug">
                    {inv.extractedClaim}
                  </p>
                  <div className="mt-2 flex items-center gap-1.5 text-[11px] font-mono text-slate-500 tabular-nums">
                    <span>{inv.independentSourceCount} indep.</span>
                    <span aria-hidden="true">·</span>
                    <span>{inv.totalSourceCount} sources</span>
                    {inv.isReferenceCase && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span>Reference</span>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          </div>

          <div className="pt-4 mt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={handleDownloadCodeZip}
              disabled={isDownloadingZip}
              className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 text-xs font-medium text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded transition-colors disabled:opacity-60 whitespace-nowrap cursor-pointer"
            >
              {isDownloadingZip ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
              ) : (
                <FileArchive className="w-3.5 h-3.5" aria-hidden="true" />
              )}
              <span>
                {isDownloadingZip ? 'Packaging ZIP…' : 'Download App Code (.zip)'}
              </span>
            </button>
          </div>
        </aside>

        {/* Primary Content Area */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 space-y-6">
          {/* Error Banner */}
          {errorMessage && (
            <div
              role="alert"
              className="flex items-start justify-between gap-4 p-4 bg-red-50 border border-red-300 rounded-md text-sm text-red-900"
            >
              <div>
                <span className="font-semibold">Investigation error: </span>
                {errorMessage}
              </div>
              <button
                type="button"
                onClick={() => setErrorMessage(null)}
                aria-label="Dismiss error"
                className="text-red-700 hover:text-red-900 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {activeView === 'network' && (
            <SourceNetworkView
              investigations={investigations}
              onOpenInvestigation={(id) => {
                setActiveId(id);
                setActiveView('workspace');
              }}
            />
          )}

          {activeView === 'standard' && <EvidenceStandardView />}

          {(activeView === 'workspace' || activeView === 'graph') && (
            <>
              {/* Claim / URL Submission Bar */}
              {activeView === 'workspace' && (
                <section className="bg-white border border-slate-200 rounded-md p-5 sm:p-6 space-y-4">
                  <div className="flex flex-col md:flex-row md:items-end justify-between gap-2">
                    <div>
                      <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                        Investigate a claim, headline, or URL
                      </h1>
                      <p className="text-sm text-slate-600 mt-1">
                        TRACE breaks statements into verifiable questions, maps source dependencies, searches for counter-evidence, and flags missing records.
                      </p>
                    </div>
                  </div>

                  <form
                    onSubmit={handleSubmitForm}
                    className="flex flex-col sm:flex-row gap-3"
                  >
                    <div className="relative flex-1">
                      <Search
                        className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2"
                        aria-hidden="true"
                      />
                      <input
                        ref={inputRef}
                        type="text"
                        value={submissionInput}
                        onChange={(e) => setSubmissionInput(e.target.value)}
                        disabled={isInvestigating}
                        placeholder="Paste a viral claim, headline, quote, or public https:// article URL…"
                        className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-md focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-600 disabled:opacity-60"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={isInvestigating || submissionInput.trim().length < 4}
                      className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-blue-700 rounded-md hover:bg-blue-800 disabled:opacity-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      {isInvestigating ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>Investigating…</span>
                        </>
                      ) : (
                        <>
                          <span>Launch Investigation</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </form>

                  {/* Starter Viral Claims */}
                  <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                    <span className="text-slate-500 font-medium mr-1">
                      Try live search on:
                    </span>
                    {STARTER_CLAIMS.map((sample) => (
                      <button
                        key={sample.title}
                        type="button"
                        disabled={isInvestigating}
                        onClick={() => {
                          setSubmissionInput(sample.input);
                          runInvestigation(sample.input);
                        }}
                        className="px-2.5 py-1 text-xs text-slate-700 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 rounded transition-colors cursor-pointer disabled:opacity-50"
                      >
                        {sample.title}
                      </button>
                    ))}
                  </div>
                </section>
              )}

              {/* Loading Skeleton during live Gemini Search Grounding */}
              {isInvestigating && (
                <section className="bg-white border border-slate-200 rounded-md p-6 space-y-4">
                  <div className="flex items-center gap-3">
                    <Loader2 className="w-5 h-5 text-blue-700 animate-spin shrink-0" />
                    <div>
                      <h2 className="text-base font-semibold text-slate-900">
                        Running live open-web investigation…
                      </h2>
                      <p className="text-xs text-slate-600 mt-0.5">
                        Decomposing claim, querying independent sources, tracing Source DNA, checking contradictions, and cataloging unknowns.
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 pt-2">
                    {[
                      '01. Extracting sub-questions',
                      '02. Grounding web sources',
                      '03. Detecting copied reposts',
                      '04. Mapping counter-evidence',
                    ].map((step) => (
                      <div
                        key={step}
                        className="p-3 bg-slate-50 border border-slate-200 rounded text-xs font-mono text-slate-600"
                      >
                        {step}
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Active Dossier Workspace */}
              {!isInvestigating && activeInvestigation && (
                <div className="space-y-6">
                  {activeView === 'graph' ? (
                    <div className="space-y-4">
                      <div className="flex flex-wrap items-center justify-between gap-4 bg-white border border-slate-200 rounded-md px-5 py-4">
                        <div className="space-y-1">
                          <div className="text-xs font-mono text-slate-500">
                            ACTIVE DOSSIER · {activeInvestigation.independentSourceCount} INDEPENDENT /{' '}
                            {activeInvestigation.totalSourceCount} SOURCES
                          </div>
                          <h2 className="text-lg font-semibold text-slate-900">
                            {activeInvestigation.extractedClaim}
                          </h2>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <StatusIndicator status={activeInvestigation.overallStatus} />
                          <button
                            type="button"
                            onClick={handleExportPdf}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                          >
                            {pdfExported ? (
                              <Check className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
                            ) : (
                              <Download className="w-3.5 h-3.5" aria-hidden="true" />
                            )}
                            <span>{pdfExported ? 'PDF Exported' : 'Export PDF'}</span>
                          </button>
                        </div>
                      </div>

                      <EvidenceGraph
                        investigation={activeInvestigation}
                        selectedEvidenceId={selectedEvidenceId}
                        onSelectEvidence={setSelectedEvidenceId}
                      />
                    </div>
                  ) : (
                    <>
                      {/* Case Summary & Decomposed Sub-Questions */}
                      <section className="bg-white border border-slate-200 rounded-md p-6 space-y-6">
                        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4 pb-5 border-b border-slate-200">
                          <div className="space-y-2 max-w-3xl">
                            <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-slate-500 tabular-nums">
                              <span>
                                {activeInvestigation.isReferenceCase
                                  ? 'REFERENCE CASE STUDY'
                                  : 'LIVE INVESTIGATION'}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span>
                                Checked{' '}
                                {new Date(
                                  activeInvestigation.lastCheckedAt
                                ).toLocaleDateString()}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span>
                                {activeInvestigation.independentSourceCount} independent /{' '}
                                {activeInvestigation.totalSourceCount} total sources
                              </span>
                            </div>

                            <h2
                              className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug"
                              style={{ textWrap: 'balance' }}
                            >
                              {activeInvestigation.extractedClaim}
                            </h2>

                            <p className="text-xs text-slate-600">
                              <span className="font-semibold text-slate-800">
                                Submitted input:{' '}
                              </span>
                              {activeInvestigation.submittedType === 'url' ? (
                                <span className="inline-flex items-center gap-1 font-mono">
                                  <Link2 className="w-3 h-3" />
                                  {activeInvestigation.submittedInput}
                                </span>
                              ) : (
                                `“${activeInvestigation.submittedInput}”`
                              )}
                            </p>
                          </div>

                          <div className="flex flex-col items-start lg:items-end gap-2.5 shrink-0">
                            <StatusIndicator status={activeInvestigation.overallStatus} />
                            <span className="text-xs text-slate-500">
                              TRACE Evidence Standard
                            </span>
                            <button
                              type="button"
                              onClick={handleExportPdf}
                              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                            >
                              {pdfExported ? (
                                <Check className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
                              ) : (
                                <Download className="w-3.5 h-3.5" aria-hidden="true" />
                              )}
                              <span>{pdfExported ? 'PDF Exported' : 'Export PDF'}</span>
                            </button>
                          </div>
                        </div>

                        {/* Transparent Conclusion Box */}
                        <div className="p-4 sm:p-5 bg-slate-50 border border-slate-200 rounded-md space-y-2">
                          <div className="text-xs font-mono font-semibold text-slate-500">
                            TRACE CONCLUSION (INSPECTABLE TRAIL BELOW)
                          </div>
                          <h3 className="text-base font-semibold text-slate-900">
                            {activeInvestigation.conclusionHeadline}
                          </h3>
                          <p className="text-sm text-slate-700 leading-relaxed">
                            {activeInvestigation.conclusionDetail}
                          </p>
                        </div>

                        {/* Decomposed Investigative Questions */}
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <h3 className="text-sm font-semibold text-slate-900">
                              Decomposed Investigative Questions
                            </h3>
                            <span className="text-xs text-slate-500">
                              Click any question to trace its linked source
                            </span>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {activeInvestigation.subQuestions.map((q, idx) => {
                              const isSelected = selectedQuestionId === q.id;
                              return (
                                <button
                                  key={q.id}
                                  type="button"
                                  onClick={() => {
                                    setSelectedQuestionId(
                                      isSelected ? null : q.id
                                    );
                                    if (q.evidenceIds[0]) {
                                      setSelectedEvidenceId(q.evidenceIds[0]);
                                    }
                                  }}
                                  className={`text-left p-4 border rounded-md transition-colors cursor-pointer space-y-2 ${
                                    isSelected
                                      ? 'border-blue-600 bg-blue-50/40'
                                      : 'border-slate-200 bg-white hover:border-slate-300'
                                  }`}
                                >
                                  <div className="flex items-center justify-between gap-2">
                                    <span className="font-mono text-xs text-slate-400 tabular-nums">
                                      QUESTION {String(idx + 1).padStart(2, '0')}
                                    </span>
                                    <StatusIndicator status={q.status} compact />
                                  </div>
                                  <div className="text-sm font-semibold text-slate-900">
                                    {q.question}
                                  </div>
                                  <p className="text-xs text-slate-600 leading-relaxed">
                                    {q.findingSummary}
                                  </p>
                                </button>
                              );
                            })}
                          </div>
                        </div>

                        {/* Grounded Web Links Strip */}
                        {activeInvestigation.groundingUrls.length > 0 && (
                          <div className="pt-4 border-t border-slate-200">
                            <div className="text-xs font-mono text-slate-500 mb-2">
                              VERIFIED SEARCH GROUNDING SOURCES (
                              {activeInvestigation.groundingUrls.length})
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {activeInvestigation.groundingUrls.map((g, idx) => (
                                <a
                                  key={`${g.uri}-${idx}`}
                                  href={g.uri}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs text-blue-800 bg-blue-50/70 border border-blue-200 rounded hover:bg-blue-100/70 transition-colors max-w-xs"
                                >
                                  <CheckCircle2 className="w-3 h-3 shrink-0" />
                                  <span className="truncate">{g.title}</span>
                                  <ExternalLink className="w-3 h-3 shrink-0" />
                                </a>
                              ))}
                            </div>
                          </div>
                        )}
                      </section>

                      {/* 02. Interactive Evidence Graph */}
                      <EvidenceGraph
                        investigation={activeInvestigation}
                        selectedEvidenceId={selectedEvidenceId}
                        onSelectEvidence={setSelectedEvidenceId}
                      />

                      {/* 01. Source DNA */}
                      <SourceDnaPanel investigation={activeInvestigation} />

                      {/* 03. Contradiction Engine & 04. Context Shift Detector */}
                      <ContradictionAndContextPanel
                        investigation={activeInvestigation}
                        onSelectEvidence={(id) => {
                          setSelectedEvidenceId(id);
                          setActiveView('graph');
                        }}
                      />

                      {/* 05. Unknowns Panel & TRACE LIVE Timeline */}
                      <UnknownsAndTimelinePanel
                        investigation={activeInvestigation}
                        isRefreshing={isRefreshing}
                        onRunLiveCheck={handleRunLiveCheck}
                        isSubmittingChallenge={isSubmittingChallenge}
                        onSubmitChallenge={handleSubmitChallenge}
                      />

                      {/* Inspectable Evidence Ledger */}
                      <EvidenceLedger
                        investigation={activeInvestigation}
                        selectedEvidenceId={selectedEvidenceId}
                        onSelectEvidence={setSelectedEvidenceId}
                      />
                    </>
                  )}
                </div>
              )}

              {!isInvestigating && !activeInvestigation && (
                <div className="bg-white border border-slate-200 rounded-md p-12 text-center space-y-3">
                  <FolderOpen className="w-8 h-8 text-slate-400 mx-auto" />
                  <h2 className="text-base font-semibold text-slate-900">
                    No active investigation selected
                  </h2>
                  <p className="text-sm text-slate-600">
                    Submit a claim or URL above to generate an inspectable evidence trail.
                  </p>
                </div>
              )}
            </>
          )}
          <footer className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
            <span>TRACE — Investigate everything. Trust nothing blindly.</span>
            <button
              type="button"
              onClick={handleDownloadCodeZip}
              disabled={isDownloadingZip}
              className="inline-flex items-center gap-1.5 font-medium text-slate-700 hover:text-slate-900 hover:underline disabled:opacity-60 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <FileArchive className="w-3.5 h-3.5" aria-hidden="true" />
              <span>
                {isDownloadingZip ? 'Packaging ZIP…' : 'Download App Code (.zip)'}
              </span>
            </button>
          </footer>
        </main>
      </div>
    </div>
  );
}
