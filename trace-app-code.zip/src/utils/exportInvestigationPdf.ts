import { jsPDF } from 'jspdf';
import { EVIDENCE_STANDARD_SPECS } from '../data/referenceCases';
import type { EvidenceStatus, Investigation } from '../types/trace';

function pdfSafe(input: string | undefined | null): string {
  if (!input) return '';
  return input
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/\u2014/g, ' -- ')
    .replace(/\u2013/g, '-')
    .replace(/\u2026/g, '...')
    .replace(/\u00B7/g, '|')
    .replace(/[^\x20-\x7E\n]/g, ' ');
}

function getStatusRgb(status: EvidenceStatus): [number, number, number] {
  switch (status) {
    case 'supported':
      return [21, 128, 61];
    case 'partially_supported':
      return [180, 83, 9];
    case 'contradicted':
      return [185, 28, 28];
    case 'outdated':
      return [109, 40, 217];
    default:
      return [71, 85, 105];
  }
}

function buildFilename(investigation: Investigation): string {
  const slug = investigation.extractedClaim
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 42);
  const datePart = new Date().toISOString().split('T')[0];
  return `trace-${slug || 'investigation'}-${datePart}.pdf`;
}

export function exportInvestigationPdf(investigation: Investigation): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'letter',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginX = 44;
  const marginTop = 48;
  const marginBottom = 48;
  const contentWidth = pageWidth - marginX * 2;
  let y = marginTop;

  const ensureSpace = (neededPt: number) => {
    if (y + neededPt > pageHeight - marginBottom) {
      doc.addPage();
      y = marginTop;
    }
  };

  const drawHairline = (gapBefore = 6, gapAfter = 12) => {
    y += gapBefore;
    ensureSpace(8);
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.75);
    doc.line(marginX, y, pageWidth - marginX, y);
    y += gapAfter;
  };

  const writeSectionHeading = (title: string) => {
    ensureSpace(34);
    y += 8;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text(pdfSafe(title), marginX, y);
    y += 6;
    doc.setDrawColor(203, 213, 225);
    doc.setLineWidth(0.8);
    doc.line(marginX, y, pageWidth - marginX, y);
    y += 14;
  };

  const writeWrappedText = (
    text: string,
    options: {
      font?: 'helvetica' | 'courier';
      style?: 'normal' | 'bold' | 'italic';
      size?: number;
      color?: [number, number, number];
      indent?: number;
      maxWidth?: number;
      lineHeight?: number;
      spaceAfter?: number;
    } = {}
  ) => {
    const {
      font = 'helvetica',
      style = 'normal',
      size = 9.5,
      color = [51, 65, 85],
      indent = 0,
      maxWidth = contentWidth - indent,
      lineHeight = size * 1.42,
      spaceAfter = 4,
    } = options;

    const clean = pdfSafe(text);
    if (!clean.trim()) return;

    doc.setFont(font, style);
    doc.setFontSize(size);
    doc.setTextColor(color[0], color[1], color[2]);

    const lines = doc.splitTextToSize(clean, maxWidth) as string[];
    for (const line of lines) {
      ensureSpace(lineHeight + 2);
      doc.text(line, marginX + indent, y);
      y += lineHeight;
    }
    y += spaceAfter;
  };

  // --- Masthead ---
  doc.setFont('courier', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(29, 78, 216);
  doc.text("TRACE | THE INTERNET'S EVIDENCE ENGINE", marginX, y);

  const statusSpec =
    EVIDENCE_STANDARD_SPECS[investigation.overallStatus] ??
    EVIDENCE_STANDARD_SPECS.unresolved;
  const [sr, sg, sb] = getStatusRgb(investigation.overallStatus);
  const statusLabel = `STATUS: ${statusSpec.label.toUpperCase()}`;

  doc.setFont('courier', 'bold');
  doc.setFontSize(8.5);
  const badgeWidth = doc.getTextWidth(statusLabel) + 14;
  doc.setDrawColor(sr, sg, sb);
  doc.setLineWidth(0.9);
  doc.rect(pageWidth - marginX - badgeWidth, y - 11, badgeWidth, 16);
  doc.setTextColor(sr, sg, sb);
  doc.text(statusLabel, pageWidth - marginX - badgeWidth + 7, y);

  y += 18;

  // Dossier metadata strip
  const metaLine = [
    investigation.isReferenceCase ? 'Reference Case Study' : 'Live Investigation',
    `ID: ${investigation.id}`,
    `Created: ${new Date(investigation.createdAt).toLocaleDateString('en-US')}`,
    `Last Checked: ${new Date(investigation.lastCheckedAt).toLocaleDateString('en-US')}`,
    `Sources: ${investigation.independentSourceCount} independent / ${investigation.totalSourceCount} total`,
  ].join('  |  ');

  writeWrappedText(metaLine, {
    font: 'courier',
    size: 7.5,
    color: [100, 116, 139],
    spaceAfter: 10,
  });

  // --- 01. Claim & Summary ---
  writeWrappedText(investigation.extractedClaim, {
    font: 'helvetica',
    style: 'bold',
    size: 15,
    color: [15, 23, 42],
    lineHeight: 20,
    spaceAfter: 6,
  });

  writeWrappedText(`Submitted input: ${investigation.submittedInput}`, {
    size: 9,
    color: [71, 85, 105],
    spaceAfter: 3,
  });
  writeWrappedText(`Claim scope: ${investigation.claimScope}`, {
    size: 9,
    color: [71, 85, 105],
    spaceAfter: 10,
  });

  // Conclusion Callout Box
  const conclusionHeadLines = doc.splitTextToSize(
    pdfSafe(investigation.conclusionHeadline),
    contentWidth - 20
  ) as string[];
  const conclusionBodyLines = doc.splitTextToSize(
    pdfSafe(investigation.conclusionDetail),
    contentWidth - 20
  ) as string[];
  const boxHeight =
    26 +
    conclusionHeadLines.length * 14 +
    conclusionBodyLines.length * 13 +
    10;

  ensureSpace(boxHeight + 8);
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.setLineWidth(0.75);
  doc.rect(marginX, y, contentWidth, boxHeight, 'FD');

  let boxY = y + 15;
  doc.setFont('courier', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text('TRACE CONCLUSION (VERIFIED AGAINST TRACE EVIDENCE STANDARD)', marginX + 10, boxY);
  boxY += 15;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  for (const line of conclusionHeadLines) {
    doc.text(line, marginX + 10, boxY);
    boxY += 14;
  }
  boxY += 2;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.2);
  doc.setTextColor(51, 65, 85);
  for (const line of conclusionBodyLines) {
    doc.text(line, marginX + 10, boxY);
    boxY += 13;
  }

  y += boxHeight + 12;

  // --- 02. Decomposed Sub-Questions ---
  writeSectionHeading('01. Decomposed Investigative Questions');
  if (investigation.subQuestions.length === 0) {
    writeWrappedText('No decomposed sub-questions recorded.', { size: 9 });
  } else {
    investigation.subQuestions.forEach((q, idx) => {
      const qSpec = EVIDENCE_STANDARD_SPECS[q.status] ?? EVIDENCE_STANDARD_SPECS.unresolved;
      const qColor = getStatusRgb(q.status);
      ensureSpace(44);
      writeWrappedText(
        `Q${idx + 1} [${qSpec.label.toUpperCase()}]: ${q.question}`,
        {
          style: 'bold',
          size: 9.5,
          color: qColor,
          spaceAfter: 2,
        }
      );
      writeWrappedText(q.findingSummary, {
        size: 9,
        color: [51, 65, 85],
        indent: 14,
        spaceAfter: 7,
      });
    });
  }

  // --- 03. Evidence Ledger ---
  writeSectionHeading(
    `02. Inspectable Evidence Ledger (${investigation.evidence.length} Records)`
  );

  if (investigation.evidence.length === 0) {
    writeWrappedText('No evidence records captured.', { size: 9 });
  } else {
    investigation.evidence.forEach((ev, idx) => {
      ensureSpace(92);

      const stanceLabel = `${String(idx + 1).padStart(2, '0')} | ${ev.stance.toUpperCase()} | ${
        ev.isIndependent ? 'INDEPENDENT' : 'DERIVATIVE'
      }`;
      const stanceColor: [number, number, number] =
        ev.stance === 'contradicting'
          ? [185, 28, 28]
          : ev.stance === 'supporting'
            ? [21, 128, 61]
            : [29, 78, 216];

      writeWrappedText(stanceLabel, {
        font: 'courier',
        style: 'bold',
        size: 8,
        color: stanceColor,
        spaceAfter: 2,
      });

      writeWrappedText(ev.title, {
        style: 'bold',
        size: 10,
        color: [15, 23, 42],
        spaceAfter: 2,
      });

      const evMeta = [
        ev.domain,
        ev.sourceType,
        `Published: ${ev.publicationDate}`,
        `Retrieved: ${ev.retrievalDate}`,
        ev.originStatus,
        ev.evidenceBasis,
      ].join('  |  ');

      writeWrappedText(evMeta, {
        font: 'courier',
        size: 7.5,
        color: [100, 116, 139],
        spaceAfter: 4,
      });

      writeWrappedText(ev.summary, {
        size: 9,
        color: [30, 41, 59],
        spaceAfter: 3,
      });

      if (ev.quoteOrExcerpt) {
        writeWrappedText(`Excerpt: ${ev.quoteOrExcerpt}`, {
          style: 'italic',
          size: 8.5,
          color: [71, 85, 105],
          indent: 10,
          spaceAfter: 3,
        });
      }

      writeWrappedText(`Limitations: ${ev.limitations}`, {
        size: 8.5,
        color: [146, 64, 14],
        spaceAfter: 3,
      });

      const relevantQ = investigation.subQuestions.find(
        (q) => q.id === ev.relevantQuestionId
      );
      if (relevantQ) {
        writeWrappedText(`Relevant claim question: ${relevantQ.question}`, {
          size: 8.2,
          color: [71, 85, 105],
          spaceAfter: 3,
        });
      }

      if (ev.url) {
        ensureSpace(14);
        doc.setFont('courier', 'normal');
        doc.setFontSize(7.8);
        doc.setTextColor(29, 78, 216);
        const urlDisplay = pdfSafe(ev.url);
        const urlLines = doc.splitTextToSize(`Source URL: ${urlDisplay}`, contentWidth) as string[];
        urlLines.forEach((line, lineIdx) => {
          ensureSpace(11);
          if (lineIdx === 0) {
            doc.textWithLink(line, marginX, y, { url: ev.url });
          } else {
            doc.text(line, marginX, y);
          }
          y += 11;
        });
        y += 2;
      }

      if (idx < investigation.evidence.length - 1) {
        drawHairline(3, 9);
      } else {
        y += 6;
      }
    });
  }

  // --- 04. Source DNA & Context Shift ---
  writeSectionHeading('03. Source DNA & Context Shift Analysis');

  if (investigation.sourceDna.length > 0) {
    investigation.sourceDna.forEach((node, idx) => {
      const parent = node.dependsOnId
        ? investigation.sourceDna.find((n) => n.id === node.dependsOnId)
        : undefined;
      writeWrappedText(
        `${String(idx + 1).padStart(2, '0')}. [${node.role}] ${node.label} (${node.date}${
          node.domain ? ` | ${node.domain}` : ''
        })`,
        {
          style: 'bold',
          size: 9,
          color: [15, 23, 42],
          spaceAfter: 1,
        }
      );
      writeWrappedText(
        `${node.notes}${parent ? ` (Cites/repeats: ${parent.label})` : ''}`,
        {
          size: 8.5,
          color: [71, 85, 105],
          indent: 14,
          spaceAfter: 5,
        }
      );
    });
  }

  writeWrappedText(
    `Context Shift Detector [${investigation.contextShift.severity}]: ${investigation.contextShift.summary}`,
    {
      style: 'bold',
      size: 9,
      color: investigation.contextShift.detected ? [180, 83, 9] : [21, 128, 61],
      spaceAfter: 3,
    }
  );
  if (investigation.contextShift.originalContext) {
    writeWrappedText(`Original context: ${investigation.contextShift.originalContext}`, {
      size: 8.5,
      indent: 12,
      spaceAfter: 2,
    });
  }
  if (investigation.contextShift.currentFraming) {
    writeWrappedText(`Current framing: ${investigation.contextShift.currentFraming}`, {
      size: 8.5,
      indent: 12,
      spaceAfter: 2,
    });
  }
  if (investigation.contextShift.temporalGap) {
    writeWrappedText(`Temporal gap: ${investigation.contextShift.temporalGap}`, {
      size: 8.5,
      indent: 12,
      spaceAfter: 6,
    });
  }

  // --- 05. Unknowns Panel ---
  writeSectionHeading(
    `04. Unknowns & Verification Gaps (${investigation.unknowns.length})`
  );
  if (investigation.unknowns.length === 0) {
    writeWrappedText('No unresolved documentary gaps flagged.', { size: 9 });
  } else {
    investigation.unknowns.forEach((u, idx) => {
      writeWrappedText(`${idx + 1}. ${u.gap}`, {
        style: 'bold',
        size: 9.2,
        color: [15, 23, 42],
        spaceAfter: 2,
      });
      writeWrappedText(`Why it matters: ${u.whyItMatters}`, {
        size: 8.5,
        indent: 12,
        spaceAfter: 2,
      });
      writeWrappedText(`Required to verify: ${u.requiredToVerify}`, {
        size: 8.5,
        indent: 12,
        spaceAfter: 6,
      });
    });
  }

  // --- 06. TRACE LIVE Timeline ---
  if (investigation.timeline.length > 0) {
    writeSectionHeading('05. TRACE LIVE Investigation Timeline');
    investigation.timeline.forEach((ev) => {
      const ts = new Date(ev.timestamp).toLocaleString('en-US');
      const statusSuffix = ev.statusAfter
        ? ` -> ${EVIDENCE_STANDARD_SPECS[ev.statusAfter]?.label ?? ev.statusAfter}`
        : '';
      writeWrappedText(`${ts} | ${ev.eventType}${statusSuffix}`, {
        font: 'courier',
        style: 'bold',
        size: 8,
        color: [71, 85, 105],
        spaceAfter: 1,
      });
      writeWrappedText(ev.summary, {
        size: 8.8,
        color: [30, 41, 59],
        indent: 10,
        spaceAfter: ev.deltaDetails ? 2 : 5,
      });
      if (ev.deltaDetails) {
        writeWrappedText(ev.deltaDetails, {
          size: 8.3,
          color: [100, 116, 139],
          indent: 10,
          spaceAfter: 5,
        });
      }
    });
  }

  // --- Running Footers across all pages ---
  const totalPages = doc.getNumberOfPages();
  const exportedStamp = new Date().toLocaleString('en-US');
  for (let p = 1; p <= totalPages; p += 1) {
    doc.setPage(p);
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.6);
    doc.line(marginX, pageHeight - 32, pageWidth - marginX, pageHeight - 32);

    doc.setFont('courier', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text(
      pdfSafe(`TRACE Evidence Standard Dossier | Exported ${exportedStamp}`),
      marginX,
      pageHeight - 20
    );
    const pageText = `Page ${p} of ${totalPages}`;
    doc.text(
      pageText,
      pageWidth - marginX - doc.getTextWidth(pageText),
      pageHeight - 20
    );
  }

  doc.save(buildFilename(investigation));
}
