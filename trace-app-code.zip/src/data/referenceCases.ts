import type { EvidenceStatus, Investigation } from '../types/trace';

export interface EvidenceStandardSpec {
  status: EvidenceStatus;
  label: string;
  meaning: string;
  textColor: string;
  bgTint: string;
  borderColor: string;
  graphStroke: string;
}

export const EVIDENCE_STANDARD_SPECS: Record<EvidenceStatus, EvidenceStandardSpec> = {
  supported: {
    status: 'supported',
    label: 'Supported',
    meaning: 'Strong primary or independent evidence directly supports the claim as stated.',
    textColor: 'text-emerald-800',
    bgTint: 'bg-emerald-50',
    borderColor: 'border-emerald-300',
    graphStroke: '#15803d',
  },
  partially_supported: {
    status: 'partially_supported',
    label: 'Partially Supported',
    meaning: 'Core elements exist, but the claim omits qualifiers, overstates scope, or relies on single-origin reporting.',
    textColor: 'text-amber-800',
    bgTint: 'bg-amber-50',
    borderColor: 'border-amber-300',
    graphStroke: '#b45309',
  },
  contradicted: {
    status: 'contradicted',
    label: 'Contradicted',
    meaning: 'Credible primary records or official documentation conflict with the claim.',
    textColor: 'text-red-800',
    bgTint: 'bg-red-50',
    borderColor: 'border-red-300',
    graphStroke: '#b91c1c',
  },
  unresolved: {
    status: 'unresolved',
    label: 'Unresolved',
    meaning: 'Available public evidence is insufficient to establish or refute the claim.',
    textColor: 'text-slate-700',
    bgTint: 'bg-slate-100',
    borderColor: 'border-slate-300',
    graphStroke: '#475569',
  },
  outdated: {
    status: 'outdated',
    label: 'Outdated',
    meaning: 'The claim reflects an earlier state of events that has since been superseded or corrected.',
    textColor: 'text-violet-800',
    bgTint: 'bg-violet-50',
    borderColor: 'border-violet-300',
    graphStroke: '#6d28d9',
  },
};

export const STARTER_CLAIMS: Array<{ title: string; input: string }> = [
  {
    title: 'Viral tech outage claim',
    input: 'Did OpenAI or Cloudflare confirm a global outage affecting enterprise APIs this week?',
  },
  {
    title: 'Regulatory policy rumor',
    input: 'The EU has banned all open-weight AI models starting this year.',
  },
  {
    title: 'Science & health headline',
    input: 'A new study proved microplastics have been eliminated from municipal tap water by boiling alone.',
  },
  {
    title: 'Market / company shutdown rumor',
    input: 'Humane AI Pin servers were shut down and customer devices stopped working.',
  },
];

export const REFERENCE_INVESTIGATIONS: Investigation[] = [
  {
    id: 'ref-student-policy',
    submittedInput: 'A new policy has been announced waiving transit and lab fees for all students.',
    submittedType: 'claim',
    extractedClaim: 'A newly announced administrative policy waives transit and lab fees for all enrolled students.',
    claimScope: 'Applies universal scope ("all students") across the district without institutional or income qualifiers.',
    createdAt: '2026-11-22T14:10:00.000Z',
    lastCheckedAt: '2026-11-22T18:45:00.000Z',
    isReferenceCase: true,
    overallStatus: 'partially_supported',
    conclusionHeadline: 'Claim is too broad: official circular limits the waiver to four pilot campuses.',
    conclusionDetail:
      'While an authentic administrative memorandum exists, both viral news summaries trace back to the same paraphrased press digest. The underlying memorandum restricts eligibility to pilot-tier campuses and excludes graduate lab surcharges.',
    independentSourceCount: 2,
    totalSourceCount: 4,
    subQuestions: [
      {
        id: 'q-1',
        question: 'Who originally made this claim and is there an official announcement?',
        findingSummary:
          'Originated in a regional education bulletin summarizing a Board of Trustees memorandum dated Nov 18.',
        status: 'supported',
        evidenceIds: ['ev-ref-1', 'ev-ref-2'],
      },
      {
        id: 'q-2',
        question: 'Are news articles reporting independently or repeating the same source?',
        findingSummary:
          'Two secondary campus blogs repeat the same headline verbatim from the initial digest without citing the PDF annex.',
        status: 'partially_supported',
        evidenceIds: ['ev-ref-2', 'ev-ref-3'],
      },
      {
        id: 'q-3',
        question: 'Is there primary evidence contradicting the "all students" scope?',
        findingSummary:
          'Section 4(b) of the published policy annex explicitly restricts the waiver to four designated pilot schools.',
        status: 'contradicted',
        evidenceIds: ['ev-ref-4'],
      },
      {
        id: 'q-4',
        question: 'What implementation details remain unverified?',
        findingSummary:
          'Whether the Board intends to expand the pilot budget in Spring 2027 is not recorded in public minutes.',
        status: 'unresolved',
        evidenceIds: [],
      },
    ],
    evidence: [
      {
        id: 'ev-ref-1',
        title: 'Regional Education Digest: Fall Fee Relief Summary',
        url: '',
        domain: 'edudigest.example.org',
        sourceType: 'Independent Reporting',
        publicationDate: '2026-11-19',
        retrievalDate: '2026-11-22',
        originStatus: 'Original',
        evidenceBasis: 'Direct Evidence',
        stance: 'origin',
        relevantQuestionId: 'q-1',
        summary:
          'First public summary introducing the phrase "fee relief for students" in its headline.',
        quoteOrExcerpt:
          '"District trustees approved an immediate waiver covering commuter transit passes and selected lab fees."',
        limitations:
          'Headline omitted eligibility annex; article body referenced "participating campuses" only in paragraph six.',
        isIndependent: true,
      },
      {
        id: 'ev-ref-2',
        title: 'Campus Wire Syndicate: Students Receive Blanket Fee Waiver',
        url: '',
        domain: 'campuswire.example.net',
        sourceType: 'Derivative Repost',
        publicationDate: '2026-11-20',
        retrievalDate: '2026-11-22',
        originStatus: 'Copied / Syndicated',
        evidenceBasis: 'Inference',
        stance: 'supporting',
        relevantQuestionId: 'q-2',
        summary:
          'Rewrote the Education Digest headline into a universal claim ("all students") without independent verification.',
        quoteOrExcerpt:
          '"Under the newly announced directive, all students are eligible for waived transit and lab costs."',
        limitations:
          'No independent reporting; relies entirely on ev-ref-1 and drops the pilot qualifier.',
        parentEvidenceId: 'ev-ref-1',
        isIndependent: false,
      },
      {
        id: 'ev-ref-3',
        title: 'Metro Student Forum Viral Thread',
        url: '',
        domain: 'social.example.com',
        sourceType: 'Social Media Post',
        publicationDate: '2026-11-20',
        retrievalDate: '2026-11-22',
        originStatus: 'Re-framed',
        evidenceBasis: 'Inference',
        stance: 'supporting',
        relevantQuestionId: 'q-2',
        summary:
          'Shared screenshot of Campus Wire Syndicate headline, driving 14,000+ reposts.',
        quoteOrExcerpt:
          '"Finally confirmed — every student gets free transit and zero lab fees starting Monday."',
        limitations:
          'Social amplification of a derivative article; introduces false effective date ("starting Monday").',
        parentEvidenceId: 'ev-ref-2',
        isIndependent: false,
      },
      {
        id: 'ev-ref-4',
        title: 'Board Memorandum 2026-118 Annex B: Pilot Eligibility Schedule',
        url: '',
        domain: 'board-records.example.gov',
        sourceType: 'Primary Record',
        publicationDate: '2026-11-18',
        retrievalDate: '2026-11-22',
        originStatus: 'Original',
        evidenceBasis: 'Direct Evidence',
        stance: 'contradicting',
        relevantQuestionId: 'q-3',
        summary:
          'Official signed annex defining the geographic and enrollment boundaries of the fee waiver.',
        quoteOrExcerpt:
          '"Section 4(b): Fee exemptions under Pilot Phase I apply solely to full-time undergraduates enrolled at North, Eastview, Harbor, and Valley Technical campuses."',
        limitations:
          'Does not clarify whether graduate teaching fellows are covered under separate union agreements.',
        isIndependent: true,
      },
    ],
    sourceDna: [
      {
        id: 'dna-1',
        label: 'Board Memorandum 2026-118 Annex B',
        domain: 'board-records.example.gov',
        date: '2026-11-18',
        role: 'Primary Official Source',
        notes: 'Establishes the narrow 4-campus pilot scope.',
      },
      {
        id: 'dna-2',
        label: 'Regional Education Digest',
        domain: 'edudigest.example.org',
        date: '2026-11-19',
        role: 'Earliest Discoverable Origin',
        dependsOnId: 'dna-1',
        notes: 'First news summary; softened the pilot restriction in its headline.',
      },
      {
        id: 'dna-3',
        label: 'Campus Wire Syndicate',
        domain: 'campuswire.example.net',
        date: '2026-11-20',
        role: 'Amplifier / Repost',
        dependsOnId: 'dna-2',
        notes: 'Copied summary and generalized headline to "all students".',
      },
      {
        id: 'dna-4',
        label: 'Metro Student Forum Thread',
        domain: 'social.example.com',
        date: '2026-11-20',
        role: 'Amplifier / Repost',
        dependsOnId: 'dna-3',
        notes: 'Screenshot amplification creating viral spread.',
      },
    ],
    contextShift: {
      detected: true,
      severity: 'Minor Reframing',
      summary:
        'A narrow Phase I pilot policy was generalized into a universal mandate during secondary syndication.',
      originalContext: 'Pilot waiver limited to 4 campuses for full-time undergraduates (Nov 18 Annex B).',
      currentFraming: 'Universal waiver for "all students" effective immediately (Nov 20 social reposts).',
      temporalGap: '2 days between primary record and viral reframing',
    },
    unknowns: [
      {
        id: 'unk-1',
        gap: 'Phase II expansion criteria and funding threshold',
        whyItMatters:
          'Determines whether remaining campuses could receive the waiver later in the academic year.',
        requiredToVerify: 'Published Board Finance Committee minutes or FY2027 budget resolution.',
      },
      {
        id: 'unk-2',
        gap: 'Exact effective billing date for eligible pilot students',
        whyItMatters: 'Viral posts claim "starting Monday", which is not stated in Annex B.',
        requiredToVerify: 'Registrar bursar implementation circular.',
      },
    ],
    timeline: [
      {
        id: 'tl-ref-1',
        timestamp: '2026-11-22T14:10:00.000Z',
        eventType: 'Initial Investigation',
        summary:
          'Extracted 4 sub-questions; traced 2 viral articles back to single secondary digest and located contradicting Annex B.',
        statusAfter: 'partially_supported',
      },
      {
        id: 'tl-ref-2',
        timestamp: '2026-11-22T18:45:00.000Z',
        eventType: 'Live Update',
        summary:
          'Verified no addendum issued by Board Registrar as of Nov 22 evening; claim scope remains restricted.',
        statusAfter: 'partially_supported',
        deltaDetails: 'Confirmed Annex B remains the latest binding policy document.',
      },
    ],
    challenges: [],
    groundingUrls: [],
  },
  {
    id: 'ref-bridge-closure',
    submittedInput: 'Major arterial river bridge closed indefinitely after structural emergency this morning.',
    submittedType: 'claim',
    extractedClaim: 'The arterial river bridge is closed indefinitely to all traffic due to a structural emergency.',
    claimScope: 'Full, indefinite closure effective immediately.',
    createdAt: '2026-11-21T09:00:00.000Z',
    lastCheckedAt: '2026-11-22T12:30:00.000Z',
    isReferenceCase: true,
    overallStatus: 'outdated',
    conclusionHeadline: 'Initial partial closure was real, but full-closure framing relies on a 2022 archive photo and is now outdated.',
    conclusionDetail:
      'Department of Transportation telemetry confirms a two-lane inspection closure occurred early Nov 21, but the viral image circulating alongside "indefinite shutdown" headlines is from a 2022 barge incident. All lanes reopened following structural clearance.',
    independentSourceCount: 3,
    totalSourceCount: 3,
    subQuestions: [
      {
        id: 'q-b1',
        question: 'Did transportation authorities announce a structural bridge closure?',
        findingSummary: 'DOT issued a 4-hour eastbound lane inspection advisory, not an indefinite shutdown.',
        status: 'partially_supported',
        evidenceIds: ['ev-b1'],
      },
      {
        id: 'q-b2',
        question: 'Is the widely shared photograph of buckled decking from this incident?',
        findingSummary: 'Image metadata and archive match place the photograph in October 2022.',
        status: 'contradicted',
        evidenceIds: ['ev-b2'],
      },
      {
        id: 'q-b3',
        question: 'What is the current operational status of the bridge?',
        findingSummary: 'Reopened to full traffic at 15:20 local time per DOT clearance notice.',
        status: 'outdated',
        evidenceIds: ['ev-b3'],
      },
    ],
    evidence: [
      {
        id: 'ev-b1',
        title: 'DOT Traffic Advisory #409: Eastbound Inspection Closure',
        url: '',
        domain: 'dot.example.gov',
        sourceType: 'Official Statement',
        publicationDate: '2026-11-21',
        retrievalDate: '2026-11-21',
        originStatus: 'Original',
        evidenceBasis: 'Direct Evidence',
        stance: 'origin',
        relevantQuestionId: 'q-b1',
        summary: 'Scheduled emergency bearing inspection closed two eastbound lanes for four hours.',
        quoteOrExcerpt: '"Eastbound lanes 1–2 restricted 07:00–11:00 for joint inspection; westbound traffic unaffected."',
        limitations: 'Initial bulletin did not include post-inspection engineering sign-off.',
        isIndependent: true,
      },
      {
        id: 'ev-b2',
        title: 'Harbor Maritime Archive Photo #2022-10-14',
        url: '',
        domain: 'archives.example.org',
        sourceType: 'Archive / Earlier Context',
        publicationDate: '2022-10-14',
        retrievalDate: '2026-11-21',
        originStatus: 'Re-framed',
        evidenceBasis: 'Direct Evidence',
        stance: 'contradicting',
        relevantQuestionId: 'q-b2',
        summary: 'Identical decking image published four years prior following a barge strike.',
        quoteOrExcerpt: '"Fig. 3: Expansion joint damage documented October 14, 2022 prior to 2023 rehabilitation."',
        limitations: 'Requires reverse visual confirmation against individual social repost crops.',
        isIndependent: true,
      },
      {
        id: 'ev-b3',
        title: 'DOT Clearance Bulletin: Full Span Reopened',
        url: '',
        domain: 'dot.example.gov',
        sourceType: 'Official Statement',
        publicationDate: '2026-11-21',
        retrievalDate: '2026-11-22',
        originStatus: 'Original',
        evidenceBasis: 'Direct Evidence',
        stance: 'contradicting',
        relevantQuestionId: 'q-b3',
        summary: 'Engineering team cleared the span and restored full traffic capacity.',
        quoteOrExcerpt: '"All lanes reopened at 15:20 following ultrasonic inspection; no structural load restrictions."',
        limitations: 'Full written engineering report pending 14-day public release.',
        isIndependent: true,
      },
    ],
    sourceDna: [
      {
        id: 'dna-b1',
        label: 'DOT Advisory #409 (Partial Closure)',
        domain: 'dot.example.gov',
        date: '2026-11-21 07:00',
        role: 'Primary Official Source',
        notes: 'Origin of actual lane restriction.',
      },
      {
        id: 'dna-b2',
        label: '2022 Maritime Archive Photo',
        domain: 'archives.example.org',
        date: '2022-10-14',
        role: 'Earliest Discoverable Origin',
        notes: 'Recycled photo merged into viral "indefinite shutdown" posts.',
      },
      {
        id: 'dna-b3',
        label: 'DOT Clearance Bulletin',
        domain: 'dot.example.gov',
        date: '2026-11-21 15:20',
        role: 'Correction / Update',
        dependsOnId: 'dna-b1',
        notes: 'Superseded earlier restriction; span fully open.',
      },
    ],
    contextShift: {
      detected: true,
      severity: 'Material Context Shift',
      summary: 'A 2022 barge-strike archive photograph was paired with a routine 4-hour lane advisory to imply a catastrophic collapse.',
      originalContext: 'October 2022 structural inspection photo prior to 2023 bridge retrofit.',
      currentFraming: 'Presented on Nov 21, 2026 as breaking structural failure.',
      temporalGap: '4 years, 1 month',
    },
    unknowns: [
      {
        id: 'unk-b1',
        gap: 'Detailed ultrasonic engineering inspection PDF',
        whyItMatters: 'Confirms whether minor bearing wear triggered the unscheduled 4-hour check.',
        requiredToVerify: 'Public works structural inspection log (due in 14 days).',
      },
    ],
    timeline: [
      {
        id: 'tl-b1',
        timestamp: '2026-11-21T09:00:00.000Z',
        eventType: 'Initial Investigation',
        summary: 'Confirmed partial 2-lane restriction; flagged unverified decking image.',
        statusAfter: 'partially_supported',
      },
      {
        id: 'tl-b2',
        timestamp: '2026-11-21T15:30:00.000Z',
        eventType: 'Correction Detected',
        summary: 'Matched viral image to Oct 2022 archive and logged DOT full reopening notice.',
        statusAfter: 'outdated',
        deltaDetails: 'Status shifted from Partially Supported to Outdated after span reopened.',
      },
    ],
    challenges: [],
    groundingUrls: [],
  },
];
