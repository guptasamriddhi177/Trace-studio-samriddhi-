import React, { useMemo, useState } from 'react';
import {
  ExternalLink,
  Maximize2,
  ZoomIn,
  ZoomOut,
  AlertCircle,
  CheckCircle2,
  XCircle,
  HelpCircle,
  GitBranch,
} from 'lucide-react';
import type {
  EvidenceItem,
  Investigation,
  SubQuestion,
  UnknownItem,
} from '../types/trace';
import { EVIDENCE_STANDARD_SPECS } from '../data/referenceCases';
import { StatusIndicator } from './StatusIndicator';

interface EvidenceGraphProps {
  investigation: Investigation;
  selectedEvidenceId: string | null;
  onSelectEvidence: (id: string | null) => void;
}

type GraphFilter = 'all' | 'supporting' | 'contradicting' | 'dependencies' | 'unknowns';

type SelectedNode =
  | { kind: 'claim' }
  | { kind: 'question'; data: SubQuestion }
  | { kind: 'evidence'; data: EvidenceItem }
  | { kind: 'unknown'; data: UnknownItem };

function truncateLabel(text: string, maxLen: number): string {
  if (text.length <= maxLen) return text;
  return `${text.slice(0, maxLen - 1)}…`;
}

export function EvidenceGraph({
  investigation,
  selectedEvidenceId,
  onSelectEvidence,
}: EvidenceGraphProps) {
  const [filter, setFilter] = useState<GraphFilter>('all');
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [dragging, setDragging] = useState<{ startX: number; startY: number; origX: number; origY: number } | null>(null);
  const [hoveredNodeId, setHoveredNodeId] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<SelectedNode>({ kind: 'claim' });

  const layout = useMemo(() => {
    const width = 980;
    const claimPos = { x: width / 2, y: 66 };

    const questions = investigation.subQuestions;
    const qSpacing = width / Math.max(questions.length + 1, 2);
    const qPositions = questions.map((q, idx) => ({
      id: q.id,
      x: qSpacing * (idx + 1),
      y: 196,
      data: q,
    }));

    const filteredEvidence = investigation.evidence.filter((ev) => {
      if (filter === 'supporting') return ev.stance === 'supporting' || ev.stance === 'origin';
      if (filter === 'contradicting') return ev.stance === 'contradicting';
      if (filter === 'dependencies') return Boolean(ev.parentEvidenceId) || !ev.isIndependent;
      if (filter === 'unknowns') return false;
      return true;
    });

    const evSpacing = width / Math.max(filteredEvidence.length + 1, 2);
    const evPositions = filteredEvidence.map((ev, idx) => ({
      id: ev.id,
      x: evSpacing * (idx + 1),
      y: ev.parentEvidenceId ? 378 : 332,
      data: ev,
    }));

    const showUnknowns = filter === 'all' || filter === 'unknowns';
    const unknowns = showUnknowns ? investigation.unknowns : [];
    const unkSpacing = width / Math.max(unknowns.length + 1, 2);
    const unkPositions = unknowns.map((u, idx) => ({
      id: u.id,
      x: unkSpacing * (idx + 1),
      y: 486,
      data: u,
    }));

    const height = unknowns.length > 0 ? 550 : 440;

    return {
      width,
      height,
      claimPos,
      qPositions,
      evPositions,
      unkPositions,
    };
  }, [investigation, filter]);

  const activeEvidence =
    selectedNode.kind === 'evidence'
      ? selectedNode.data
      : selectedEvidenceId
        ? investigation.evidence.find((e) => e.id === selectedEvidenceId) ?? null
        : null;

  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    if ((e.target as HTMLElement).closest('[data-node="true"]')) return;
    setDragging({
      startX: e.clientX,
      startY: e.clientY,
      origX: pan.x,
      origY: pan.y,
    });
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!dragging) return;
    setPan({
      x: dragging.origX + (e.clientX - dragging.startX),
      y: dragging.origY + (e.clientY - dragging.startY),
    });
  };

  const handleMouseUp = () => setDragging(null);

  const resetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const overallSpec = EVIDENCE_STANDARD_SPECS[investigation.overallStatus];

  return (
    <div className="bg-white border border-slate-200 rounded-md overflow-hidden">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-3.5 border-b border-slate-200 bg-slate-50/70">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">
            02. Interactive Evidence Graph
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Click any claim, question, source, or gap node to inspect the underlying evidence trail.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-md">
            {(
              [
                ['all', 'All Nodes'],
                ['supporting', 'Supporting'],
                ['contradicting', 'Contradictions'],
                ['dependencies', 'Copied / Reposts'],
                ['unknowns', 'Unknowns'],
              ] as Array<[GraphFilter, string]>
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setFilter(key)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  filter === key
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex items-center border border-slate-200 rounded-md bg-white">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.65, Number((z - 0.15).toFixed(2))))}
              aria-label="Zoom out graph"
              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-50 border-r border-slate-200 cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="px-2 text-xs font-mono tabular-nums text-slate-600">
              {Math.round(zoom * 100)}%
            </span>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(1.6, Number((z + 0.15).toFixed(2))))}
              aria-label="Zoom in graph"
              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-50 border-l border-slate-200 cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={resetView}
              aria-label="Reset graph view"
              className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-50 border-l border-slate-200 cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Canvas + Inspector Split */}
      <div className="grid grid-cols-1 xl:grid-cols-12">
        <div className="xl:col-span-8 relative bg-slate-50/40 border-b xl:border-b-0 xl:border-r border-slate-200 overflow-hidden">
          <svg
            viewBox={`0 0 ${layout.width} ${layout.height}`}
            className={`w-full h-[460px] select-none ${
              dragging ? 'cursor-grabbing' : 'cursor-grab'
            }`}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
          >
            <defs>
              <pattern
                id="trace-grid"
                width="24"
                height="24"
                patternUnits="userSpaceOnUse"
              >
                <path
                  d="M 24 0 L 0 0 0 24"
                  fill="none"
                  stroke="#e2e8f0"
                  strokeWidth="0.7"
                />
              </pattern>
            </defs>

            <rect width={layout.width} height={layout.height} fill="url(#trace-grid)" />

            <g
              transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}
              style={{ transformOrigin: 'center center' }}
            >
              {/* Edges: Claim -> Sub-Questions */}
              {layout.qPositions.map((qp) => {
                const isHighlighted =
                  hoveredNodeId === qp.id || hoveredNodeId === 'claim';
                const strokeColor =
                  EVIDENCE_STANDARD_SPECS[qp.data.status]?.graphStroke ?? '#64748b';
                return (
                  <path
                    key={`edge-claim-${qp.id}`}
                    d={`M ${layout.claimPos.x} ${layout.claimPos.y + 28} C ${layout.claimPos.x} 135, ${qp.x} 130, ${qp.x} ${qp.y - 26}`}
                    fill="none"
                    stroke={strokeColor}
                    strokeOpacity={isHighlighted ? 0.95 : 0.45}
                    strokeWidth={isHighlighted ? 2.2 : 1.5}
                  />
                );
              })}

              {/* Edges: Sub-Questions -> Evidence */}
              {layout.evPositions.map((ep) => {
                const parentQ =
                  layout.qPositions.find((q) => q.id === ep.data.relevantQuestionId) ??
                  layout.qPositions[0];
                if (!parentQ) return null;
                const stanceColor =
                  ep.data.stance === 'contradicting'
                    ? '#b91c1c'
                    : ep.data.stance === 'supporting'
                      ? '#15803d'
                      : ep.data.stance === 'origin'
                        ? '#1d4ed8'
                        : '#475569';
                const isHighlighted =
                  hoveredNodeId === ep.id || hoveredNodeId === parentQ.id;

                return (
                  <path
                    key={`edge-q-${parentQ.id}-${ep.id}`}
                    d={`M ${parentQ.x} ${parentQ.y + 26} C ${parentQ.x} 266, ${ep.x} 266, ${ep.x} ${ep.y - 24}`}
                    fill="none"
                    stroke={stanceColor}
                    strokeOpacity={isHighlighted ? 0.95 : 0.45}
                    strokeWidth={isHighlighted ? 2 : 1.3}
                  />
                );
              })}

              {/* Edges: Source DNA Dependencies (Copied / Syndicated) */}
              {layout.evPositions.map((ep) => {
                if (!ep.data.parentEvidenceId) return null;
                const parentEv = layout.evPositions.find(
                  (p) => p.id === ep.data.parentEvidenceId
                );
                if (!parentEv) return null;
                return (
                  <path
                    key={`edge-dep-${parentEv.id}-${ep.id}`}
                    d={`M ${parentEv.x} ${parentEv.y + 24} Q ${(parentEv.x + ep.x) / 2} ${Math.max(parentEv.y, ep.y) + 46}, ${ep.x} ${ep.y + 24}`}
                    fill="none"
                    stroke="#d97706"
                    strokeWidth={1.6}
                    strokeDasharray="5 4"
                  />
                );
              })}

              {/* Edges: Claim / Questions -> Unknowns */}
              {layout.unkPositions.map((up) => (
                <path
                  key={`edge-unk-${up.id}`}
                  d={`M ${layout.claimPos.x} ${layout.claimPos.y + 28} C ${layout.claimPos.x} 280, ${up.x} 410, ${up.x} ${up.y - 22}`}
                  fill="none"
                  stroke="#94a3b8"
                  strokeWidth={1.2}
                  strokeDasharray="3 4"
                />
              ))}

              {/* Central Claim Node */}
              <g
                data-node="true"
                className="cursor-pointer"
                onClick={() => {
                  setSelectedNode({ kind: 'claim' });
                  onSelectEvidence(null);
                }}
                onMouseEnter={() => setHoveredNodeId('claim')}
                onMouseLeave={() => setHoveredNodeId(null)}
              >
                <rect
                  x={layout.claimPos.x - 190}
                  y={layout.claimPos.y - 28}
                  width={380}
                  height={56}
                  rx={6}
                  fill="#0f172a"
                  stroke={selectedNode.kind === 'claim' ? '#2563eb' : '#0f172a'}
                  strokeWidth={selectedNode.kind === 'claim' ? 2.5 : 1}
                />
                <text
                  x={layout.claimPos.x}
                  y={layout.claimPos.y - 6}
                  textAnchor="middle"
                  className="fill-slate-300 text-[10px] font-mono"
                >
                  CLAIM UNDER INVESTIGATION · {overallSpec.label.toUpperCase()}
                </text>
                <text
                  x={layout.claimPos.x}
                  y={layout.claimPos.y + 13}
                  textAnchor="middle"
                  className="fill-white text-[12px] font-semibold"
                >
                  {truncateLabel(investigation.extractedClaim, 54)}
                </text>
              </g>

              {/* Sub-Question Nodes */}
              {layout.qPositions.map((qp, idx) => {
                const isSelected =
                  selectedNode.kind === 'question' && selectedNode.data.id === qp.id;
                const stroke =
                  EVIDENCE_STANDARD_SPECS[qp.data.status]?.graphStroke ?? '#64748b';
                return (
                  <g
                    key={qp.id}
                    data-node="true"
                    className="cursor-pointer"
                    onClick={() => {
                      setSelectedNode({ kind: 'question', data: qp.data });
                      onSelectEvidence(null);
                    }}
                    onMouseEnter={() => setHoveredNodeId(qp.id)}
                    onMouseLeave={() => setHoveredNodeId(null)}
                  >
                    <rect
                      x={qp.x - 95}
                      y={qp.y - 26}
                      width={190}
                      height={52}
                      rx={5}
                      fill="#ffffff"
                      stroke={isSelected ? '#1d4ed8' : stroke}
                      strokeWidth={isSelected ? 2.5 : 1.5}
                    />
                    <text
                      x={qp.x - 84}
                      y={qp.y - 7}
                      className="fill-slate-500 text-[10px] font-mono"
                    >
                      Q{idx + 1} · {EVIDENCE_STANDARD_SPECS[qp.data.status]?.label}
                    </text>
                    <text
                      x={qp.x - 84}
                      y={qp.y + 11}
                      className="fill-slate-900 text-[11px] font-medium"
                    >
                      {truncateLabel(qp.data.question, 27)}
                    </text>
                  </g>
                );
              })}

              {/* Evidence Nodes */}
              {layout.evPositions.map((ep) => {
                const isSelected =
                  (selectedNode.kind === 'evidence' && selectedNode.data.id === ep.id) ||
                  selectedEvidenceId === ep.id;
                const borderColor =
                  ep.data.stance === 'contradicting'
                    ? '#b91c1c'
                    : ep.data.stance === 'supporting'
                      ? '#15803d'
                      : ep.data.stance === 'origin'
                        ? '#1d4ed8'
                        : '#64748b';
                const fill = ep.data.isIndependent ? '#ffffff' : '#fffbeb';

                return (
                  <g
                    key={ep.id}
                    data-node="true"
                    className="cursor-pointer"
                    onClick={() => {
                      setSelectedNode({ kind: 'evidence', data: ep.data });
                      onSelectEvidence(ep.data.id);
                    }}
                    onMouseEnter={() => setHoveredNodeId(ep.id)}
                    onMouseLeave={() => setHoveredNodeId(null)}
                  >
                    <rect
                      x={ep.x - 86}
                      y={ep.y - 24}
                      width={172}
                      height={48}
                      rx={4}
                      fill={fill}
                      stroke={isSelected ? '#1d4ed8' : borderColor}
                      strokeWidth={isSelected ? 2.5 : 1.4}
                    />
                    <text
                      x={ep.x - 76}
                      y={ep.y - 6}
                      className="fill-slate-500 text-[9.5px] font-mono"
                    >
                      {ep.data.stance.toUpperCase()} ·{' '}
                      {ep.data.isIndependent ? 'INDEP' : 'DERIV'}
                    </text>
                    <text
                      x={ep.x - 76}
                      y={ep.y + 11}
                      className="fill-slate-900 text-[11px] font-medium"
                    >
                      {truncateLabel(ep.data.domain || ep.data.title, 24)}
                    </text>
                  </g>
                );
              })}

              {/* Unknowns Nodes */}
              {layout.unkPositions.map((up) => {
                const isSelected =
                  selectedNode.kind === 'unknown' && selectedNode.data.id === up.id;
                return (
                  <g
                    key={up.id}
                    data-node="true"
                    className="cursor-pointer"
                    onClick={() => {
                      setSelectedNode({ kind: 'unknown', data: up.data });
                      onSelectEvidence(null);
                    }}
                    onMouseEnter={() => setHoveredNodeId(up.id)}
                    onMouseLeave={() => setHoveredNodeId(null)}
                  >
                    <rect
                      x={up.x - 105}
                      y={up.y - 22}
                      width={210}
                      height={44}
                      rx={4}
                      fill="#f8fafc"
                      stroke={isSelected ? '#1d4ed8' : '#64748b'}
                      strokeDasharray="4 3"
                      strokeWidth={isSelected ? 2 : 1.2}
                    />
                    <text
                      x={up.x - 94}
                      y={up.y - 5}
                      className="fill-slate-500 text-[9.5px] font-mono"
                    >
                      MISSING EVIDENCE
                    </text>
                    <text
                      x={up.x - 94}
                      y={up.y + 11}
                      className="fill-slate-800 text-[11px] font-medium"
                    >
                      {truncateLabel(up.data.gap, 30)}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>

          {/* Compact Graph Legend */}
          <div className="flex flex-wrap items-center gap-x-5 gap-y-1.5 px-4 py-2.5 border-t border-slate-200 bg-white text-xs text-slate-600">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-blue-700 inline-block" /> Origin / Primary
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-emerald-700 inline-block" /> Supporting
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-0.5 bg-red-700 inline-block" /> Contradicting
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-0.5 border-t-2 border-dashed border-amber-600 inline-block" /> Copied / Dependency
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-0.5 border-t-2 border-dashed border-slate-400 inline-block" /> Unresolved Gap
            </span>
          </div>
        </div>

        {/* Interactive Node Inspector */}
        <div className="xl:col-span-4 p-5 bg-white flex flex-col justify-between">
          {selectedNode.kind === 'claim' && !activeEvidence && (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-mono text-slate-500">NODE INSPECTOR · CONCLUSION</span>
                <StatusIndicator status={investigation.overallStatus} />
              </div>
              <h4 className="text-base font-semibold text-slate-900 leading-snug">
                {investigation.conclusionHeadline}
              </h4>
              <p className="text-sm text-slate-700 leading-relaxed">
                {investigation.conclusionDetail}
              </p>
              <div className="pt-3 border-t border-slate-100 space-y-2 text-xs text-slate-600">
                <div>
                  <span className="font-medium text-slate-900">Claim scope: </span>
                  {investigation.claimScope}
                </div>
                <div className="tabular-nums">
                  <span className="font-medium text-slate-900">Independence check: </span>
                  {investigation.independentSourceCount} independent out of{' '}
                  {investigation.totalSourceCount} discovered records
                </div>
              </div>
            </div>
          )}

          {selectedNode.kind === 'question' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-mono text-slate-500">SUB-QUESTION FINDING</span>
                <StatusIndicator status={selectedNode.data.status} />
              </div>
              <h4 className="text-base font-semibold text-slate-900 leading-snug">
                {selectedNode.data.question}
              </h4>
              <p className="text-sm text-slate-700 leading-relaxed">
                {selectedNode.data.findingSummary}
              </p>
              <div className="pt-3 border-t border-slate-100">
                <p className="text-xs font-medium text-slate-800 mb-2">
                  Linked Evidence ({selectedNode.data.evidenceIds.length})
                </p>
                {selectedNode.data.evidenceIds.length === 0 ? (
                  <p className="text-xs text-slate-500">
                    No direct records attached yet. Check the Unknowns Panel for missing records.
                  </p>
                ) : (
                  <div className="space-y-1.5">
                    {selectedNode.data.evidenceIds.map((evId) => {
                      const ev = investigation.evidence.find((e) => e.id === evId);
                      if (!ev) return null;
                      return (
                        <button
                          key={evId}
                          type="button"
                          onClick={() => {
                            setSelectedNode({ kind: 'evidence', data: ev });
                            onSelectEvidence(ev.id);
                          }}
                          className="w-full text-left px-3 py-2 text-xs border border-slate-200 rounded hover:border-blue-400 hover:bg-blue-50/40 transition-colors cursor-pointer"
                        >
                          <div className="font-medium text-slate-900 truncate">{ev.title}</div>
                          <div className="text-slate-500 mt-0.5">
                            {ev.domain} · {ev.sourceType}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeEvidence && (
            <div className="space-y-3.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-mono text-slate-500">
                  EVIDENCE RECORD · {activeEvidence.stance.toUpperCase()}
                </span>
                <span className="inline-flex items-center gap-1 text-xs font-mono text-slate-700">
                  {activeEvidence.stance === 'contradicting' ? (
                    <XCircle className="w-3.5 h-3.5 text-red-700" />
                  ) : activeEvidence.stance === 'supporting' ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                  ) : (
                    <GitBranch className="w-3.5 h-3.5 text-blue-700" />
                  )}
                  {activeEvidence.isIndependent ? 'Independent' : 'Derivative'}
                </span>
              </div>

              <h4 className="text-base font-semibold text-slate-900 leading-snug">
                {activeEvidence.title}
              </h4>

              <div className="text-xs text-slate-500 space-y-1">
                <div>
                  {activeEvidence.sourceType} · Published {activeEvidence.publicationDate} · Retrieved{' '}
                  {activeEvidence.retrievalDate}
                </div>
                <div>
                  {activeEvidence.originStatus} · {activeEvidence.evidenceBasis}
                </div>
              </div>

              <p className="text-sm text-slate-700 leading-relaxed">
                {activeEvidence.summary}
              </p>

              {activeEvidence.quoteOrExcerpt && (
                <blockquote className="p-3 bg-slate-50 border border-slate-200 rounded text-xs text-slate-700 italic leading-relaxed">
                  {activeEvidence.quoteOrExcerpt}
                </blockquote>
              )}

              <div className="p-3 bg-amber-50/60 border border-amber-200/80 rounded text-xs text-amber-950">
                <span className="font-semibold">Limitations: </span>
                {activeEvidence.limitations}
              </div>

              {activeEvidence.url ? (
                <a
                  href={activeEvidence.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 hover:underline pt-1"
                >
                  <span>Inspect external source ({activeEvidence.domain})</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              ) : (
                <p className="text-xs text-slate-400">
                  Reference record domain: {activeEvidence.domain}
                </p>
              )}
            </div>
          )}

          {selectedNode.kind === 'unknown' && (
            <div className="space-y-4">
              <div className="flex items-center gap-1.5 text-xs font-mono text-slate-500">
                <HelpCircle className="w-3.5 h-3.5 text-slate-600" />
                <span>UNRESOLVED EVIDENCE GAP</span>
              </div>
              <h4 className="text-base font-semibold text-slate-900">
                {selectedNode.data.gap}
              </h4>
              <div className="space-y-3 text-sm text-slate-700">
                <div>
                  <span className="font-semibold text-slate-900 block text-xs mb-0.5">
                    Why it matters
                  </span>
                  {selectedNode.data.whyItMatters}
                </div>
                <div>
                  <span className="font-semibold text-slate-900 block text-xs mb-0.5">
                    Required to verify
                  </span>
                  {selectedNode.data.requiredToVerify}
                </div>
              </div>
            </div>
          )}

          <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
            <span className="inline-flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              Drag canvas to pan · Click nodes to trace
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
