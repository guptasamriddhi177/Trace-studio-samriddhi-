import { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import type { Investigation, SourceNetworkProfile } from '../types/trace';
import { StatusIndicator } from './StatusIndicator';

interface SourceNetworkViewProps {
  investigations: Investigation[];
  onOpenInvestigation: (id: string) => void;
}

export function SourceNetworkView({
  investigations,
  onOpenInvestigation,
}: SourceNetworkViewProps) {
  const [query, setQuery] = useState('');

  const profiles = useMemo<SourceNetworkProfile[]>(() => {
    const map = new Map<string, SourceNetworkProfile>();

    for (const inv of investigations) {
      for (const ev of inv.evidence) {
        const domain = (ev.domain || 'unknown').toLowerCase();
        const existing = map.get(domain) ?? {
          domain,
          appearances: 0,
          originCount: 0,
          syndicatedCount: 0,
          contradictionInvolvement: 0,
          lastSeenAt: ev.retrievalDate,
          observedRoles: [],
        };

        existing.appearances += 1;
        if (ev.originStatus === 'Original') existing.originCount += 1;
        if (ev.originStatus !== 'Original') existing.syndicatedCount += 1;
        if (ev.stance === 'contradicting') existing.contradictionInvolvement += 1;
        if (ev.retrievalDate > existing.lastSeenAt) existing.lastSeenAt = ev.retrievalDate;
        if (!existing.observedRoles.includes(ev.sourceType)) {
          existing.observedRoles.push(ev.sourceType);
        }

        map.set(domain, existing);
      }
    }

    return Array.from(map.values()).sort((a, b) => b.appearances - a.appearances);
  }, [investigations]);

  const filteredProfiles = profiles.filter((p) =>
    p.domain.toLowerCase().includes(query.trim().toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="bg-white border border-slate-200 rounded-md p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-200">
          <div>
            <h2 className="text-xl font-semibold text-slate-900">
              TRACE Evidence Network — Source Relationship Ledger
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Tracks which domains originate primary records versus which repeatedly republish or reframe claims across your investigations.
            </p>
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter domains…"
              className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-300 rounded focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-600"
            />
          </div>
        </div>

        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs font-mono text-slate-500">
                <th className="py-2.5 pr-4 font-medium">Domain / Source</th>
                <th className="py-2.5 px-4 font-medium">Observed Types</th>
                <th className="py-2.5 px-4 font-medium text-right">Appearances</th>
                <th className="py-2.5 px-4 font-medium text-right">Original</th>
                <th className="py-2.5 px-4 font-medium text-right">Copied / Reframed</th>
                <th className="py-2.5 pl-4 font-medium text-right">Counter-Evidence</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredProfiles.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No matching domains recorded yet.
                  </td>
                </tr>
              ) : (
                filteredProfiles.map((profile) => (
                  <tr key={profile.domain} className="hover:bg-slate-50/70">
                    <td className="py-3 pr-4 font-mono text-xs font-semibold text-slate-900">
                      {profile.domain}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-600">
                      {profile.observedRoles.join(' · ')}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800">
                      {profile.appearances}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-800">
                      {profile.originCount}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-amber-800">
                      {profile.syndicatedCount}
                    </td>
                    <td className="py-3 pl-4 text-right font-mono tabular-nums text-slate-700">
                      {profile.contradictionInvolvement}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Claim History */}
      <div className="bg-white border border-slate-200 rounded-md p-6">
        <div className="pb-4 border-b border-slate-200">
          <h3 className="text-base font-semibold text-slate-900">
            Claim History & Evolving Investigation Archive
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            Preserves how claims enter the workspace, change scope, or shift status as live updates arrive.
          </p>
        </div>

        <div className="divide-y divide-slate-200 mt-2">
          {investigations.map((inv) => (
            <div
              key={inv.id}
              className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="space-y-1 max-w-3xl">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono tabular-nums">
                  <span>{new Date(inv.createdAt).toLocaleDateString()}</span>
                  <span aria-hidden="true">·</span>
                  <span>{inv.independentSourceCount} independent sources</span>
                  <span aria-hidden="true">·</span>
                  <span>{inv.timeline.length} timeline revision(s)</span>
                </div>
                <h4 className="text-sm font-semibold text-slate-900">
                  {inv.extractedClaim}
                </h4>
                <p className="text-xs text-slate-600">{inv.conclusionHeadline}</p>
              </div>

              <div className="flex items-center gap-4 shrink-0">
                <StatusIndicator status={inv.overallStatus} />
                <button
                  type="button"
                  onClick={() => onOpenInvestigation(inv.id)}
                  className="px-3 py-1.5 text-xs font-medium text-blue-700 border border-blue-200 rounded hover:bg-blue-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Open Dossier
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
