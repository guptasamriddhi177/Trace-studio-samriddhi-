import { useState } from 'react';
import { ExternalLink, Filter } from 'lucide-react';
import type { EvidenceStance, Investigation } from '../types/trace';

interface EvidenceLedgerProps {
  investigation: Investigation;
  selectedEvidenceId: string | null;
  onSelectEvidence: (id: string) => void;
}

export function EvidenceLedger({
  investigation,
  selectedEvidenceId,
  onSelectEvidence,
}: EvidenceLedgerProps) {
  const [stanceFilter, setStanceFilter] = useState<'all' | EvidenceStance>('all');
  const [independentOnly, setIndependentOnly] = useState(false);

  const filtered = investigation.evidence.filter((ev) => {
    if (stanceFilter !== 'all' && ev.stance !== stanceFilter) return false;
    if (independentOnly && !ev.isIndependent) return false;
    return true;
  });

  return (
    <section className="bg-white border border-slate-200 rounded-md overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-4 border-b border-slate-200 bg-slate-50/70">
        <div>
          <h3 className="text-base font-semibold text-slate-900">
            Inspectable Evidence Ledger (TRACE Evidence Standard)
          </h3>
          <p className="text-xs text-slate-600 mt-0.5">
            Every source carries publication date, retrieval date, origin dependency, evidence basis, and explicit limitations.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-md">
            {(
              [
                ['all', 'All'],
                ['origin', 'Origin'],
                ['supporting', 'Supporting'],
                ['contradicting', 'Contradicting'],
                ['context', 'Context'],
              ] as Array<['all' | EvidenceStance, string]>
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setStanceFilter(key)}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  stanceFilter === key
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setIndependentOnly((v) => !v)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium border rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              independentOnly
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Independent Only</span>
          </button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="p-8 text-center text-sm text-slate-500">
          No evidence items match the active filter criteria.
        </div>
      ) : (
        <div className="divide-y divide-slate-200">
          {filtered.map((item) => {
            const isSelected = selectedEvidenceId === item.id;
            const relevantQ = investigation.subQuestions.find(
              (q) => q.id === item.relevantQuestionId
            );
            const parentEv = item.parentEvidenceId
              ? investigation.evidence.find((e) => e.id === item.parentEvidenceId)
              : undefined;

            return (
              <article
                key={item.id}
                onClick={() => onSelectEvidence(item.id)}
                className={`p-6 transition-colors cursor-pointer ${
                  isSelected ? 'bg-blue-50/40' : 'hover:bg-slate-50/60'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                  <div className="space-y-2 max-w-4xl">
                    {/* Unboxed Clean Metadata Line (Zero-Pill Discipline) */}
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono">
                      <span
                        className={`font-semibold ${
                          item.stance === 'contradicting'
                            ? 'text-red-800'
                            : item.stance === 'supporting'
                              ? 'text-emerald-800'
                              : item.stance === 'origin'
                                ? 'text-blue-800'
                                : 'text-slate-700'
                        }`}
                      >
                        {item.stance.toUpperCase()}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{item.sourceType}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">Published {item.publicationDate}</span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">Retrieved {item.retrievalDate}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.originStatus}</span>
                      <span aria-hidden="true">·</span>
                      <span>{item.evidenceBasis}</span>
                    </div>

                    <h4 className="text-base font-semibold text-slate-900">
                      {item.title}
                    </h4>

                    <p className="text-sm text-slate-700 leading-relaxed">
                      {item.summary}
                    </p>

                    {item.quoteOrExcerpt && (
                      <p className="text-xs text-slate-600 italic bg-slate-50 px-3 py-2 border border-slate-200 rounded">
                        {item.quoteOrExcerpt}
                      </p>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1 text-xs">
                      <div className="text-slate-600">
                        <span className="font-semibold text-slate-900">Limitations: </span>
                        {item.limitations}
                      </div>
                      {relevantQ && (
                        <div className="text-slate-600">
                          <span className="font-semibold text-slate-900">Relevant claim: </span>
                          {relevantQ.question}
                        </div>
                      )}
                    </div>

                    {parentEv && (
                      <div className="text-xs text-amber-900 pt-0.5">
                        Source dependency: Derived from or cites “{parentEv.title}”
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col items-start lg:items-end gap-2 shrink-0">
                    <span className="font-mono text-xs text-slate-600">
                      {item.domain}
                    </span>
                    {item.url ? (
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 border border-blue-200 bg-blue-50/50 rounded hover:bg-blue-100/60 transition-colors whitespace-nowrap shrink-0"
                      >
                        <span>Open Source</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    ) : (
                      <span className="text-xs text-slate-400">Archival reference record</span>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}
