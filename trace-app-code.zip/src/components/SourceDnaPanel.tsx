import { ArrowRight, Copy, ExternalLink, GitCommitHorizontal } from 'lucide-react';
import type { Investigation, SourceDnaNode } from '../types/trace';

interface SourceDnaPanelProps {
  investigation: Investigation;
}

function getRoleStyles(role: SourceDnaNode['role']): string {
  switch (role) {
    case 'Primary Official Source':
      return 'text-blue-800 bg-blue-50 border-blue-200';
    case 'Earliest Discoverable Origin':
      return 'text-slate-900 bg-slate-100 border-slate-300';
    case 'Independent Corroboration':
      return 'text-emerald-800 bg-emerald-50 border-emerald-200';
    case 'Amplifier / Repost':
      return 'text-amber-800 bg-amber-50 border-amber-200';
    case 'Correction / Update':
      return 'text-violet-800 bg-violet-50 border-violet-200';
  }
}

export function SourceDnaPanel({ investigation }: SourceDnaPanelProps) {
  const { sourceDna, independentSourceCount, totalSourceCount } = investigation;
  const derivativeCount = Math.max(0, totalSourceCount - independentSourceCount);

  return (
    <section className="bg-white border border-slate-200 rounded-md p-6">
      <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h3 className="text-base font-semibold text-slate-900">
            01. Source DNA & Propagation Lineage
          </h3>
          <p className="text-sm text-slate-600 mt-0.5">
            Traces the claim back to its earliest discoverable appearance and separates independent reporting from copied reposts.
          </p>
        </div>

        <div className="flex items-center gap-6 text-xs tabular-nums">
          <div>
            <span className="text-slate-500 block">Independent Sources</span>
            <span className="font-mono text-sm font-semibold text-slate-900">
              {independentSourceCount} of {totalSourceCount}
            </span>
          </div>
          <div className="h-7 w-px bg-slate-200" aria-hidden="true" />
          <div>
            <span className="text-slate-500 block">Copied / Derivative</span>
            <span className="font-mono text-sm font-semibold text-amber-800">
              {derivativeCount} detected
            </span>
          </div>
        </div>
      </div>

      {sourceDna.length === 0 ? (
        <p className="text-sm text-slate-500 py-6">
          No propagation lineage nodes extracted for this record yet.
        </p>
      ) : (
        <div className="mt-5 space-y-3">
          {sourceDna.map((node, index) => {
            const parentNode = node.dependsOnId
              ? sourceDna.find((n) => n.id === node.dependsOnId)
              : undefined;
            const isDerivative = node.role === 'Amplifier / Repost';

            return (
              <div
                key={node.id}
                className={`flex flex-col md:flex-row md:items-center justify-between gap-3 p-3.5 border rounded-md ${
                  isDerivative
                    ? 'border-amber-200 bg-amber-50/30'
                    : 'border-slate-200 bg-white'
                } ${node.dependsOnId ? 'md:ml-6' : ''}`}
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="font-mono tabular-nums text-slate-400">
                      {String(index + 1).padStart(2, '0')}
                    </span>
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 border rounded-sm font-mono text-[11px] font-medium ${getRoleStyles(node.role)}`}
                    >
                      {isDerivative ? (
                        <Copy className="w-3 h-3" aria-hidden="true" />
                      ) : (
                        <GitCommitHorizontal className="w-3 h-3" aria-hidden="true" />
                      )}
                      {node.role}
                    </span>
                    <span className="font-mono text-slate-500 tabular-nums">{node.date}</span>
                    {node.domain && (
                      <>
                        <span className="text-slate-300" aria-hidden="true">·</span>
                        <span className="font-mono text-slate-600">{node.domain}</span>
                      </>
                    )}
                  </div>

                  <div className="text-sm font-semibold text-slate-900">
                    {node.label}
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{node.notes}</p>

                  {parentNode && (
                    <div className="inline-flex items-center gap-1.5 text-xs text-amber-900 pt-0.5">
                      <ArrowRight className="w-3 h-3 shrink-0" aria-hidden="true" />
                      <span>Cites / repeats: {parentNode.label}</span>
                    </div>
                  )}
                </div>

                {node.url && (
                  <a
                    href={node.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 hover:underline whitespace-nowrap shrink-0"
                  >
                    <span>Open source</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
