import { AlertOctagon, CalendarClock, CheckCircle2, ExternalLink, Scale } from 'lucide-react';
import type { Investigation } from '../types/trace';

interface ContradictionAndContextPanelProps {
  investigation: Investigation;
  onSelectEvidence: (id: string) => void;
}

export function ContradictionAndContextPanel({
  investigation,
  onSelectEvidence,
}: ContradictionAndContextPanelProps) {
  const contradictingItems = investigation.evidence.filter(
    (e) => e.stance === 'contradicting'
  );
  const { contextShift } = investigation;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
      {/* 03. Contradiction Engine */}
      <section className="bg-white border border-slate-200 rounded-md p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                03. Contradiction Engine
              </h3>
              <p className="text-sm text-slate-600 mt-0.5">
                Actively searches for primary records, denials, or qualifiers that challenge the claim.
              </p>
            </div>
            <span className="inline-flex items-center gap-1.5 font-mono text-xs font-medium text-slate-700 whitespace-nowrap shrink-0">
              <Scale className="w-3.5 h-3.5 text-slate-600" aria-hidden="true" />
              <span className="tabular-nums">{contradictingItems.length} conflict(s)</span>
            </span>
          </div>

          <div className="mt-4 space-y-4">
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded">
              <span className="text-xs font-mono text-slate-500 block mb-1">
                CLAIMED SCOPE
              </span>
              <p className="text-sm text-slate-900 font-medium">
                {investigation.claimScope}
              </p>
            </div>

            {contradictingItems.length === 0 ? (
              <div className="p-4 border border-slate-200 rounded text-sm text-slate-600 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  No direct contradicting records were discovered in open web sources. Check the Unknowns Panel for remaining verification gaps.
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {contradictingItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 border border-red-200 bg-red-50/30 rounded space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-mono font-medium text-red-800 inline-flex items-center gap-1.5">
                        <AlertOctagon className="w-3.5 h-3.5" aria-hidden="true" />
                        CONTRADICTING RECORD
                      </span>
                      <span className="font-mono text-slate-500 tabular-nums">
                        {item.publicationDate} · {item.domain}
                      </span>
                    </div>

                    <h4 className="text-sm font-semibold text-slate-900">
                      {item.title}
                    </h4>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      {item.summary}
                    </p>
                    {item.quoteOrExcerpt && (
                      <p className="text-xs text-slate-600 italic">
                        {item.quoteOrExcerpt}
                      </p>
                    )}

                    <div className="pt-1 flex flex-wrap items-center gap-4 text-xs">
                      <button
                        type="button"
                        onClick={() => onSelectEvidence(item.id)}
                        className="font-medium text-blue-700 hover:underline cursor-pointer"
                      >
                        Highlight in Evidence Graph
                      </button>
                      {item.url && (
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 font-medium text-slate-700 hover:text-slate-900 hover:underline"
                        >
                          <span>Inspect source</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 04. Context Shift Detector */}
      <section className="bg-white border border-slate-200 rounded-md p-6 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-200">
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                04. Context Shift Detector
              </h3>
              <p className="text-sm text-slate-600 mt-0.5">
                Detects recycled imagery, dated announcements, or altered framing presented as new events.
              </p>
            </div>
            <span
              className={`inline-flex items-center gap-1.5 font-mono text-xs font-medium whitespace-nowrap shrink-0 ${
                contextShift.detected ? 'text-amber-800' : 'text-emerald-800'
              }`}
            >
              <CalendarClock className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{contextShift.severity}</span>
            </span>
          </div>

          <div className="mt-4 space-y-4">
            <p className="text-sm text-slate-800 leading-relaxed">
              {contextShift.summary}
            </p>

            {contextShift.detected ? (
              <div className="divide-y divide-slate-200 border border-slate-200 rounded">
                {contextShift.originalContext && (
                  <div className="p-3.5 bg-slate-50/60">
                    <span className="text-xs font-mono text-slate-500 block mb-1">
                      EARLIER / ORIGINAL CONTEXT
                    </span>
                    <p className="text-sm text-slate-800">
                      {contextShift.originalContext}
                    </p>
                  </div>
                )}
                {contextShift.currentFraming && (
                  <div className="p-3.5 bg-amber-50/40">
                    <span className="text-xs font-mono text-amber-900 block mb-1">
                      CURRENT VIRAL FRAMING
                    </span>
                    <p className="text-sm text-slate-900">
                      {contextShift.currentFraming}
                    </p>
                  </div>
                )}
                {contextShift.temporalGap && (
                  <div className="px-3.5 py-2.5 bg-white flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-medium">Detected Temporal Gap</span>
                    <span className="font-mono font-semibold text-slate-900 tabular-nums">
                      {contextShift.temporalGap}
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-4 border border-slate-200 rounded text-sm text-slate-600">
                Dates, quotations, and cited media align with the timeframe of the current event. No recycled archive context identified.
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
