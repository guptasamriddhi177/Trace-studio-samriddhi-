import { EVIDENCE_STANDARD_SPECS } from '../data/referenceCases';
import { StatusIndicator } from './StatusIndicator';
import type { EvidenceStatus } from '../types/trace';

const MANDATORY_FIELDS = [
  {
    field: 'Source Type',
    description:
      'Classifies whether a record is an Official Statement, Primary Record, Wire Service, Independent Reporting, Derivative Repost, Social Media Post, Academic Paper, or Archive.',
  },
  {
    field: 'Publication Date',
    description:
      'Original timestamp of the source document so temporal context shifts and outdated claims can be surfaced explicitly.',
  },
  {
    field: 'Retrieval Date',
    description:
      'Exact date TRACE queried and inspected the record, preserving an auditable snapshot for TRACE LIVE comparisons.',
  },
  {
    field: 'Original vs Copied Source',
    description:
      'Separates independent primary reporting from syndicated rewrites or screenshot amplification.',
  },
  {
    field: 'Direct Evidence vs Inference',
    description:
      'Distinguishes raw documentary proof (e.g. a signed policy annex) from analytical inference or secondary commentary.',
  },
  {
    field: 'Limitations',
    description:
      'Every evidence card must state what the source fails to prove, omits, or leaves ambiguous.',
  },
  {
    field: 'Relevant Claim / Sub-Question',
    description:
      'Maps each piece of evidence directly to the specific decomposed question it supports, contradicts, or contextualizes.',
  },
];

export function EvidenceStandardView() {
  const orderedStatuses: EvidenceStatus[] = [
    'supported',
    'partially_supported',
    'contradicted',
    'unresolved',
    'outdated',
  ];

  return (
    <div className="space-y-8 max-w-5xl">
      <div className="bg-white border border-slate-200 rounded-md p-6 md:p-8 space-y-4">
        <span className="font-mono text-xs text-blue-700 font-medium">
          VERIFICATION METHODOLOGY
        </span>
        <h2 className="text-2xl font-bold text-slate-900">
          The TRACE Evidence Standard
        </h2>
        <p className="text-sm text-slate-700 leading-relaxed max-w-3xl">
          Opaque percentage truth scores obscure uncertainty and invite blind trust. Instead of collapsing complex public events into an arbitrary number, every TRACE investigation classifies claims using five explicit evidence states and requires seven inspectable metadata attributes on every source.
        </p>
      </div>

      {/* 5 Statuses Table */}
      <div className="bg-white border border-slate-200 rounded-md overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/70">
          <h3 className="text-base font-semibold text-slate-900">
            01. Five-State Evidence Classification
          </h3>
        </div>
        <div className="divide-y divide-slate-200">
          {orderedStatuses.map((status) => {
            const spec = EVIDENCE_STANDARD_SPECS[status];
            return (
              <div
                key={status}
                className="px-6 py-4 flex flex-col sm:flex-row sm:items-center gap-4"
              >
                <div className="w-48 shrink-0">
                  <StatusIndicator status={status} />
                </div>
                <p className="text-sm text-slate-700">{spec.meaning}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* 7 Mandatory Attributes */}
      <div className="bg-white border border-slate-200 rounded-md overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/70">
          <h3 className="text-base font-semibold text-slate-900">
            02. Seven Mandatory Record Attributes
          </h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:gap-px bg-slate-200">
          {MANDATORY_FIELDS.map((item, idx) => (
            <div key={item.field} className="bg-white p-6 space-y-1.5">
              <div className="font-mono text-xs text-slate-400 tabular-nums">
                {String(idx + 1).padStart(2, '0')}
              </div>
              <h4 className="text-sm font-semibold text-slate-900">{item.field}</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
