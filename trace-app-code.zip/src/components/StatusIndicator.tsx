import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  HelpCircle,
  XCircle,
} from 'lucide-react';
import { EVIDENCE_STANDARD_SPECS } from '../data/referenceCases';
import type { EvidenceStatus } from '../types/trace';

interface StatusIndicatorProps {
  status: EvidenceStatus;
  compact?: boolean;
}

export function StatusIndicator({ status, compact = false }: StatusIndicatorProps) {
  const spec = EVIDENCE_STANDARD_SPECS[status] ?? EVIDENCE_STANDARD_SPECS.unresolved;

  const Icon =
    status === 'supported'
      ? CheckCircle2
      : status === 'partially_supported'
        ? AlertTriangle
        : status === 'contradicted'
          ? XCircle
          : status === 'outdated'
            ? Clock
            : HelpCircle;

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-mono font-medium whitespace-nowrap shrink-0 ${
        compact ? 'text-xs' : 'text-xs px-2 py-0.5 border rounded-sm'
      } ${spec.textColor} ${compact ? '' : `${spec.bgTint} ${spec.borderColor}`}`}
    >
      <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>{spec.label}</span>
    </span>
  );
}
