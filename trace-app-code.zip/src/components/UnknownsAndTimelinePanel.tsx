import React, { useState } from 'react';
import {
  HelpCircle,
  Loader2,
  MessageSquarePlus,
  RefreshCw,
  Clock,
  ExternalLink,
} from 'lucide-react';
import type { Investigation } from '../types/trace';
import { StatusIndicator } from './StatusIndicator';

interface UnknownsAndTimelinePanelProps {
  investigation: Investigation;
  isRefreshing: boolean;
  onRunLiveCheck: () => Promise<void>;
  isSubmittingChallenge: boolean;
  onSubmitChallenge: (note: string, referenceUrl: string) => Promise<void>;
}

function formatUtcTimestamp(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

export function UnknownsAndTimelinePanel({
  investigation,
  isRefreshing,
  onRunLiveCheck,
  isSubmittingChallenge,
  onSubmitChallenge,
}: UnknownsAndTimelinePanelProps) {
  const [note, setNote] = useState('');
  const [refUrl, setRefUrl] = useState('');
  const [showChallengeForm, setShowChallengeForm] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const handleChallengeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (note.trim().length < 5) {
      setFormError('Enter at least 5 characters explaining the evidence or counter-argument.');
      return;
    }
    setFormError(null);
    await onSubmitChallenge(note.trim(), refUrl.trim());
    setNote('');
    setRefUrl('');
    setShowChallengeForm(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* 05. Unknowns Panel */}
      <section className="lg:col-span-5 bg-white border border-slate-200 rounded-md p-6">
        <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-200">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              05. Unknowns Panel
            </h3>
            <p className="text-sm text-slate-600 mt-0.5">
              What TRACE cannot establish and what records are needed to resolve it.
            </p>
          </div>
          <span className="font-mono text-xs text-slate-600 tabular-nums whitespace-nowrap shrink-0">
            {investigation.unknowns.length} gap(s)
          </span>
        </div>

        <div className="mt-4 space-y-4">
          {investigation.unknowns.length === 0 ? (
            <p className="text-sm text-slate-500">
              No major unresolved documentary gaps flagged.
            </p>
          ) : (
            investigation.unknowns.map((item) => (
              <div
                key={item.id}
                className="pb-4 border-b border-slate-100 last:border-b-0 last:pb-0 space-y-1.5"
              >
                <div className="flex items-start gap-2">
                  <HelpCircle
                    className="w-4 h-4 text-slate-500 shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <h4 className="text-sm font-semibold text-slate-900">
                    {item.gap}
                  </h4>
                </div>
                <p className="text-xs text-slate-600 pl-6 leading-relaxed">
                  <span className="font-medium text-slate-800">Why it matters: </span>
                  {item.whyItMatters}
                </p>
                <p className="text-xs text-slate-600 pl-6 leading-relaxed">
                  <span className="font-medium text-slate-800">Required to verify: </span>
                  {item.requiredToVerify}
                </p>
              </div>
            ))
          )}
        </div>
      </section>

      {/* TRACE LIVE Timeline & Collective Evidence Contribution */}
      <section className="lg:col-span-7 bg-white border border-slate-200 rounded-md p-6 space-y-6">
        <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              TRACE LIVE — Evolving Evidence Record
            </h3>
            <p className="text-sm text-slate-600 mt-0.5">
              Re-query web sources for corrections, official addendums, or scope changes over time.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowChallengeForm((v) => !v)}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <MessageSquarePlus className="w-3.5 h-3.5" />
              <span>Contribute Evidence</span>
            </button>

            <button
              type="button"
              onClick={onRunLiveCheck}
              disabled={isRefreshing}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 rounded hover:bg-blue-800 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {isRefreshing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <RefreshCw className="w-3.5 h-3.5" />
              )}
              <span>{isRefreshing ? 'Checking Sources…' : 'Check for Updates'}</span>
            </button>
          </div>
        </div>

        {/* Collective Investigation Challenge Form */}
        {showChallengeForm && (
          <form
            onSubmit={handleChallengeSubmit}
            className="p-4 bg-slate-50 border border-slate-200 rounded space-y-3"
          >
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-semibold text-slate-900">
                Submit Additional Evidence or Challenge Conclusion
              </h4>
              <button
                type="button"
                onClick={() => setShowChallengeForm(false)}
                className="text-xs text-slate-500 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
            </div>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
              placeholder="Describe the missing primary document, correction, or factual error in the current conclusion…"
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            <input
              type="url"
              value={refUrl}
              onChange={(e) => setRefUrl(e.target.value)}
              placeholder="Optional public source URL (https://…)"
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            {formError && <p className="text-xs text-red-700">{formError}</p>}
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isSubmittingChallenge}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded hover:bg-slate-800 disabled:opacity-60 cursor-pointer"
              >
                {isSubmittingChallenge && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>{isSubmittingChallenge ? 'Evaluating…' : 'Evaluate & Append'}</span>
              </button>
            </div>
          </form>
        )}

        {/* Timeline Events */}
        <div className="space-y-4">
          {investigation.timeline.map((event) => (
            <div
              key={event.id}
              className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-slate-100 last:border-b-0 last:pb-0"
            >
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="inline-flex items-center gap-1 font-mono text-slate-500 tabular-nums">
                    <Clock className="w-3 h-3" aria-hidden="true" />
                    {formatUtcTimestamp(event.timestamp)}
                  </span>
                  <span className="text-slate-300" aria-hidden="true">·</span>
                  <span className="font-semibold text-slate-800">{event.eventType}</span>
                </div>
                <p className="text-sm text-slate-800">{event.summary}</p>
                {event.deltaDetails && (
                  <p className="text-xs text-slate-600">{event.deltaDetails}</p>
                )}
              </div>

              {event.statusAfter && (
                <div className="shrink-0">
                  <StatusIndicator status={event.statusAfter} compact />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Submitted Challenges */}
        {investigation.challenges.length > 0 && (
          <div className="pt-4 border-t border-slate-200 space-y-3">
            <h4 className="text-xs font-mono text-slate-500">
              CONTRIBUTED EVIDENCE & CHALLENGES ({investigation.challenges.length})
            </h4>
            {investigation.challenges.map((c) => (
              <div
                key={c.id}
                className="p-3.5 border border-slate-200 bg-slate-50/70 rounded space-y-1.5 text-xs"
              >
                <div className="flex items-center justify-between text-slate-500 font-mono tabular-nums">
                  <span>INVESTIGATOR NOTE</span>
                  <span>{formatUtcTimestamp(c.submittedAt)}</span>
                </div>
                <p className="text-sm text-slate-900 font-medium">{c.authorNote}</p>
                {c.referenceUrl && (
                  <a
                    href={c.referenceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-blue-700 hover:underline"
                  >
                    <span>{c.referenceUrl}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                {c.aiAssessment && (
                  <p className="text-slate-700 leading-relaxed pt-1">
                    <span className="font-semibold text-slate-900">TRACE Assessment: </span>
                    {c.aiAssessment}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
